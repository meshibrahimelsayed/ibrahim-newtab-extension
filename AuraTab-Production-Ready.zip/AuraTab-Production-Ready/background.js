// Quick Save: shortcut (Alt+Shift+S), toolbar button, or right-click menu.
// Writes to its own storage key so it never races with the New Tab UI state.
const KEY = "newtab_saved_v1";

const MAX_ITEMS = 2000;
let queue = Promise.resolve();

const normalize = (u) => {
  try { const x = new URL(u); x.hash = ""; return x.href.replace(/\/$/, ""); } catch { return u; }
};

function badge(text, color) {
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 1500);
}

function save(title, url) {
  if (!/^https?:\/\//i.test(url || "")) return badge("✕", "#c0392b");
  queue = queue
    .then(async () => {
      const { [KEY]: list = [] } = await chrome.storage.local.get(KEY);
      const n = normalize(url);
      if (list.some((i) => normalize(i.url) === n)) return badge("=", "#7a7a7a");
      list.unshift({ id: crypto.randomUUID(), title: (title || url).trim().slice(0, 300), url, createdAt: Date.now() });
      await chrome.storage.local.set({ [KEY]: list.slice(0, MAX_ITEMS) });
      badge("✓", "#2e9e6b");
    })
    .catch(() => badge("✕", "#c0392b"));
}

chrome.action.onClicked.addListener((tab) => save(tab.title, tab.url));

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "save-tab") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) save(tab.title, tab.url);
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: "save-to-newtab", title: "Save to New Tab", contexts: ["page", "link"] });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.linkUrl) save(info.selectionText || info.linkUrl, info.linkUrl);
  else save(tab && tab.title, info.pageUrl);
});
