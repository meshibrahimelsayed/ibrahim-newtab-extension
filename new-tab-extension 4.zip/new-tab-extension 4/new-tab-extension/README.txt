New Tab extension
1. chrome://extensions -> Developer mode
2. Load unpacked -> choose the "new-tab" folder (or press Reload if already loaded)
3. Press ? for shortcuts, the bar at the bottom right has card size and arrange.
"source" = full project (npm install && npm run build).
