/**
 * Generate luxury 3D-styled PNG icons for the Ibrahim extension.
 * Run: node scripts/generate-icons.js
 */
import { writeFileSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { deflateSync } from "node:zlib";

const root = path.dirname(fileURLToPath(import.meta.url)) + "/..";
const iconDir = path.join(root, "public/icons");
mkdirSync(iconDir, { recursive: true });

function createPng(size) {
  const bgR = 15, bgG = 16, bgB = 20;     // Dark obsidian background (#0f1014)
  const borderR = 45, borderG = 48, borderB = 56; // Soft metallic edge
  const goldR = 224, goldG = 175, goldB = 88; // Brushed gold (#e0af58)
  const highlightR = 248, highlightG = 220, highlightB = 140; // Gold highlight

  const raw = Buffer.alloc((size * 4 + 1) * size);
  const cornerRadius = Math.max(Math.round(size * 0.22), 2);

  function isInsideRoundedRect(x, y) {
    if (x >= cornerRadius && x < size - cornerRadius) return true;
    if (y >= cornerRadius && y < size - cornerRadius) return true;

    // Top-left
    if (x < cornerRadius && y < cornerRadius) {
      const dx = cornerRadius - x;
      const dy = cornerRadius - y;
      return dx * dx + dy * dy <= cornerRadius * cornerRadius;
    }
    // Top-right
    if (x >= size - cornerRadius && y < cornerRadius) {
      const dx = x - (size - cornerRadius - 1);
      const dy = cornerRadius - y;
      return dx * dx + dy * dy <= cornerRadius * cornerRadius;
    }
    // Bottom-left
    if (x < cornerRadius && y >= size - cornerRadius) {
      const dx = cornerRadius - x;
      const dy = y - (size - cornerRadius - 1);
      return dx * dx + dy * dy <= cornerRadius * cornerRadius;
    }
    // Bottom-right
    if (x >= size - cornerRadius && y >= size - cornerRadius) {
      const dx = x - (size - cornerRadius - 1);
      const dy = y - (size - cornerRadius - 1);
      return dx * dx + dy * dy <= cornerRadius * cornerRadius;
    }
    return false;
  }

  // Draw background scanlines
  for (let y = 0; y < size; y++) {
    const offset = y * (size * 4 + 1);
    raw[offset] = 0; // Filter: None
    for (let x = 0; x < size; x++) {
      const px = offset + 1 + x * 4;
      if (isInsideRoundedRect(x, y)) {
        // Subtle top-to-bottom gradient
        const factor = 1 - (y / size) * 0.15;
        raw[px] = Math.round(bgR * factor);
        raw[px + 1] = Math.round(bgG * factor);
        raw[px + 2] = Math.round(bgB * factor);
        raw[px + 3] = 255;
      } else {
        raw[px] = 0;
        raw[px + 1] = 0;
        raw[px + 2] = 0;
        raw[px + 3] = 0;
      }
    }
  }

  function setPixel(x, y, r, g, b, a = 255) {
    if (x < 0 || x >= size || y < 0 || y >= size) return;
    if (!isInsideRoundedRect(x, y)) return;
    const offset = y * (size * 4 + 1) + 1 + x * 4;
    raw[offset] = r;
    raw[offset + 1] = g;
    raw[offset + 2] = b;
    raw[offset + 3] = a;
  }

  // Draw luxury 3D "I" Monogram Emblem
  const margin = Math.max(Math.round(size * 0.22), 3);
  const barH = Math.max(Math.round(size * 0.11), 2);
  const stemW = Math.max(Math.round(size * 0.18), 2);

  const left = margin;
  const right = size - margin;
  const top = margin;
  const bottom = size - margin;
  const stemLeft = Math.round((size - stemW) / 2);
  const stemRight = stemLeft + stemW;

  // Top Bar (with metallic top highlight)
  for (let y = top; y < top + barH; y++) {
    for (let x = left; x < right; x++) {
      const isTopLine = y === top;
      setPixel(
        x,
        y,
        isTopLine ? highlightR : goldR,
        isTopLine ? highlightG : goldG,
        isTopLine ? highlightB : goldB
      );
    }
  }

  // Bottom Bar
  for (let y = bottom - barH; y < bottom; y++) {
    for (let x = left; x < right; x++) {
      setPixel(x, y, goldR, goldG, goldB);
    }
  }

  // Vertical Stem (with 3D bevel gradient effect)
  for (let y = top + barH; y < bottom - barH; y++) {
    for (let x = stemLeft; x < stemRight; x++) {
      const isHighlightColumn = x === stemLeft;
      setPixel(
        x,
        y,
        isHighlightColumn ? highlightR : goldR,
        isHighlightColumn ? highlightG : goldG,
        isHighlightColumn ? highlightB : goldB
      );
    }
  }

  // Compress PNG
  const compressed = deflateSync(raw, { level: 9 });
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  function crc32(buf) {
    let crc = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      crc ^= buf[i];
      for (let j = 0; j < 8; j++) {
        crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
      }
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const typeB = Buffer.from(type, "ascii");
    const payload = Buffer.concat([typeB, data]);
    const crcB = Buffer.alloc(4);
    crcB.writeUInt32BE(crc32(payload) >>> 0);
    return Buffer.concat([len, payload, crcB]);
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  return Buffer.concat([
    signature,
    makeChunk("IHDR", ihdr),
    makeChunk("IDAT", compressed),
    makeChunk("IEND", Buffer.alloc(0))
  ]);
}

for (const size of [16, 48, 128]) {
  const png = createPng(size);
  writeFileSync(path.join(iconDir, `icon${size}.png`), png);
  console.log(`Generated luxury icon${size}.png (${png.length} bytes)`);
}
