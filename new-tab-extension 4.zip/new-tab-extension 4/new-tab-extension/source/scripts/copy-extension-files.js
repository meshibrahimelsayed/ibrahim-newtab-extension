import { cpSync, mkdirSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.dirname(fileURLToPath(import.meta.url)) + "/..";
const distDir = path.join(root, "dist");
const rootDistDir = path.join(root, "../aurora-newtab-dist");

mkdirSync(path.join(distDir, "icons"), { recursive: true });
cpSync(path.join(root, "public/manifest.json"), path.join(distDir, "manifest.json"));
cpSync(path.join(root, "public/background.js"), path.join(distDir, "background.js"));
cpSync(path.join(root, "public/icons"), path.join(distDir, "icons"), { recursive: true });
console.log("Copied manifest.json and icons into dist/");

// Also sync to parent aurora-newtab-dist so both unpacked locations stay updated
if (existsSync(rootDistDir)) {
  cpSync(distDir, rootDistDir, { recursive: true });
  console.log("Synced dist into ../aurora-newtab-dist/");
}
