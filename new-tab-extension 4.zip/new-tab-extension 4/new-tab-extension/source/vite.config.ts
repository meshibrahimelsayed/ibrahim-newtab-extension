import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Chrome extensions can't use hashed/chunked module scripts loaded the normal
// Vite way inside a New Tab override without extra tooling, so we keep the
// output as a single predictable bundle referenced by a static index.html.
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "dist",
    emptyOutDir: true,
    rollupOptions: {
      output: {
        entryFileNames: "assets/app.js",
        chunkFileNames: "assets/[name].js",
        assetFileNames: "assets/[name].[ext]"
      }
    }
  }
});
