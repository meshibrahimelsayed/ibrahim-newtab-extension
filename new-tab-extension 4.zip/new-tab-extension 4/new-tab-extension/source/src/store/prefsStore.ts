import { useEffect, useSyncExternalStore } from "react";
import { kvGet, kvSet } from "../services/storage/kv";
import { debounce } from "../utils/debounce";

export interface Prefs { cardWidth: number; rowScale: number }
export const DEFAULT_PREFS: Prefs = { cardWidth: 250, rowScale: 1 };
const KEY = "newtab_prefs_v1";
let prefs: Prefs = DEFAULT_PREFS;
const subs = new Set<() => void>();
const emit = () => subs.forEach((f) => f());
const persist = debounce(() => void kvSet(KEY, prefs), 200);
void kvGet<Prefs>(KEY).then((v) => { prefs = { ...DEFAULT_PREFS, ...v }; emit(); });

export const setPrefs = (p: Partial<Prefs>) => { prefs = { ...prefs, ...p }; emit(); persist(); };
export const usePrefs = () => useSyncExternalStore((cb) => (subs.add(cb), () => subs.delete(cb)), () => prefs);

/** Applies card size / text size to the whole page via CSS variables. */
export function useApplyPrefs() {
  const p = usePrefs();
  useEffect(() => {
    const s = document.documentElement.style;
    s.setProperty("--card-col", `${p.cardWidth}px`);
    s.setProperty("--row-scale", String(p.rowScale));
  }, [p]);
}
