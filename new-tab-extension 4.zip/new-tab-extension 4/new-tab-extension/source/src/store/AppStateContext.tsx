import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { AppState } from "../types";
import { createDefaultState, createDefaultSettings } from "../utils/defaults";
import { kvGet, kvSet, kvSubscribe } from "../services/storage/kv";
import { deriveAppNameFromUrl } from "../utils/url";
import { debounce } from "../utils/debounce";

const STORAGE_KEY = "aurora_state_v1";

interface AppStateContextValue {
  state: AppState;
  /** Update state with an immer-less recipe: return a new state derived from the previous one. */
  update: (recipe: (draft: AppState) => AppState) => void;
  loaded: boolean;
}

const AppStateContext = createContext<AppStateContextValue | null>(null);

/**
 * Deep-merge stored state with current defaults so that newly introduced
 * fields are populated without destroying existing user data.
 *
 * Automatically repairs any "Untitled" app names by deriving clean titles from URLs.
 */
function migrateState(stored: AppState): AppState {
  const defaults = createDefaultSettings();
  const s = stored.settings ?? defaults;

  const appearance = {
    ...defaults.appearance,
    ...(s.appearance ?? {}),
    hoverTint: s.appearance?.hoverTint ?? defaults.appearance.hoverTint,
    glassBlur: s.appearance?.glassBlur ?? defaults.appearance.glassBlur,
    allowGoogleFavicons: s.appearance?.allowGoogleFavicons ?? true
  };

  const layout = {
    ...defaults.layout,
    ...(s.layout ?? {}),
    widgets: {
      ...defaults.layout.widgets,
      ...(s.layout?.widgets ?? {})
    }
  };

  // Repair any "Untitled" app names
  const cleanedApps = (stored.apps ?? []).map((app) => {
    if (!app.name || /^untitled$/i.test(app.name.trim()) || /^untitled\s*\d*$/i.test(app.name.trim())) {
      return { ...app, name: deriveAppNameFromUrl(app.url, app.name) };
    }
    return app;
  });

  return {
    ...stored,
    version: stored.version ?? 2,
    apps: cleanedApps,
    tasks: stored.tasks ?? [],
    settings: {
      ...defaults,
      ...s,
      appearance,
      layout,
      background: { ...defaults.background, ...(s.background ?? {}) },
      clock: { ...defaults.clock, ...(s.clock ?? {}) },
      weather: { ...defaults.weather, ...(s.weather ?? {}) },
      pomodoro: { ...defaults.pomodoro, ...(s.pomodoro ?? {}) }
    }
  };
}

export const AppStateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(createDefaultState);
  const [loaded, setLoaded] = useState(false);
  const stateRef = useRef(state);
  stateRef.current = state;
  // Last JSON we wrote, and whether local edits are still waiting to be written.
  const lastWrittenRef = useRef("");
  const dirtyRef = useRef(false);

  const persist = useMemo(
    () =>
      debounce((next: AppState) => {
        lastWrittenRef.current = JSON.stringify(next);
        dirtyRef.current = false;
        void kvSet(STORAGE_KEY, next);
      }, 180),
    []
  );

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const stored = await kvGet<AppState>(STORAGE_KEY);
      if (!cancelled) {
        if (stored && stored.version) {
          setState(migrateState(stored));
        } else {
          const fresh = createDefaultState();
          setState(fresh);
          void kvSet(STORAGE_KEY, fresh);
        }
        setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Pick up changes made by *other* New Tab pages. Ignore our own writes (they would
  // re-render everything for nothing) and never overwrite edits that haven't been saved yet.
  useEffect(() => {
    return kvSubscribe(STORAGE_KEY, async () => {
      const stored = await kvGet<AppState>(STORAGE_KEY);
      if (!stored || dirtyRef.current) return;
      if (JSON.stringify(stored) === lastWrittenRef.current) return;
      setState(migrateState(stored));
    });
  }, []);

  // Don't lose the last edit if the tab is closed or navigated away within the debounce window.
  useEffect(() => {
    const flush = () => persist.flush();
    const onVis = () => document.visibilityState === "hidden" && flush();
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [persist]);

  const update = useCallback(
    (recipe: (draft: AppState) => AppState) => {
      setState((prev) => {
        const next = recipe(prev);
        if (next === prev) return prev;
        dirtyRef.current = true;
        persist(next);
        return next;
      });
    },
    [persist]
  );

  const value = useMemo(() => ({ state, update, loaded }), [state, update, loaded]);

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
};

export function useAppState(): AppStateContextValue {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error("useAppState must be used within AppStateProvider");
  return ctx;
}
