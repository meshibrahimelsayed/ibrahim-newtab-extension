// ---------------------------------------------------------------------------
// Core data model. Everything here is persisted (directly or indirectly) to
// chrome.storage.local via services/storage. Keep shapes flat and versioned
// so import/export and future migrations stay simple.
// ---------------------------------------------------------------------------

export type ID = string;

export interface AppItem {
  id: ID;
  name: string;
  url: string;
  categoryId: ID;
  /** 'letter' = local monogram (default), 'custom' = user-uploaded data URL, 'favicon' = Google favicon (opt-in) */
  iconType: "letter" | "custom" | "favicon";
  iconValue?: string; // data URL for custom icons
  favorite: boolean;
  order: number;
  createdAt: number;
}

export interface Category {
  id: ID;
  name: string;
  order: number;
  createdAt: number;
}

export interface ProjectResource {
  id: ID;
  label: string;
  url: string;
}

export interface ProjectTask {
  id: ID;
  label: string;
  done: boolean;
  order: number;
  createdAt: number;
}

export interface Project {
  id: ID;
  name: string;
  color: string;
  notes: string;
  resources: ProjectResource[];
  tasks: ProjectTask[];
  order: number;
  createdAt: number;
}

export type WallpaperType = "image" | "video";

export interface Wallpaper {
  id: ID;
  name: string;
  type: WallpaperType;
  /** For images: the image data. For videos: the video data. Object URLs backed by IndexedDB blobs. */
  sourceKey: string; // key into the blob store (IndexedDB)
  posterKey?: string; // for videos, an optional poster frame blob key
  favorite: boolean;
  isBuiltIn: boolean;
  createdAt: number;
}

export type WallpaperMode = "fixed" | "random" | "daily" | "playlist" | "favorites";

export interface BackgroundSettings {
  mode: WallpaperMode;
  activeWallpaperId: ID | null;
  playlistIds: ID[];
  brightness: number; // 0-150 (%)
  contrast: number; // 0-150 (%)
  blur: number; // 0-20 (px)
  saturation: number; // 0-200 (%)
  vignette: number; // 0-100
  overlay: number; // 0-100 (dark overlay strength)
  videoAutoplay: boolean;
}

export type ThemeMode = "dark" | "light" | "auto";

export interface AppearanceSettings {
  theme: ThemeMode;
  accent: string; // hex
  glassIntensity: number; // 0-100
  /** Hex color for hover/interactive tint across all UI elements */
  hoverTint: string;
  /** Glass panel blur in px (0-32) */
  glassBlur: number;
  /** If true, allow fetching favicons from Google for apps with iconType "favicon" */
  allowGoogleFavicons: boolean;
}

export interface ClockSettings {
  hour12: boolean;
  showSeconds: boolean;
  dateFormat: "long" | "short" | "numeric";
}

export interface WeatherSettings {
  enabled: boolean;
  units: "metric" | "imperial";
  mode: "auto" | "manual";
  manualLocationName?: string;
  manualLat?: number;
  manualLon?: number;
}

export interface PomodoroSettings {
  focusMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  longBreakEvery: number; // sessions
  autoStartNext: boolean;
  soundEnabled: boolean;
}

export interface LayoutSettings {
  widgets: {
    weather: boolean;
    calendar: boolean;
    pomodoro: boolean;
    projects: boolean;
    todo: boolean;
  };
  gridDensity: "comfortable" | "compact";
}

export interface Settings {
  appearance: AppearanceSettings;
  background: BackgroundSettings;
  clock: ClockSettings;
  weather: WeatherSettings;
  pomodoro: PomodoroSettings;
  layout: LayoutSettings;
  onboardingComplete: boolean;
}

/** A personal to-do task linked to the calendar */
export interface TaskItem {
  id: ID;
  text: string;
  /** "YYYY-MM-DD" or null for unscheduled/"someday" */
  date: string | null;
  completed: boolean;
  priority: "low" | "medium" | "high";
  createdAt: number;
  completedAt: number | null;
}

export interface AppState {
  version: number;
  categories: Category[];
  apps: AppItem[];
  projects: Project[];
  wallpapers: Wallpaper[];
  settings: Settings;
  tasks: TaskItem[];
}

export interface ExportPayload {
  schema: "ibrahim-newtab" | "aurora-newtab";
  schemaVersion: number;
  exportedAt: number;
  data: Omit<AppState, "wallpapers"> & { wallpapers: Omit<Wallpaper, "sourceKey" | "posterKey">[] };
}

/** A tab/link saved via Quick Save (shortcut, toolbar button or context menu). */
export interface SavedItem {
  id: ID;
  title: string;
  url: string;
  createdAt: number;
}
