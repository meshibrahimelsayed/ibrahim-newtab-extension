import React from "react";
import { Project } from "../../types";
import { Modal } from "../common/Modal";
import { safeNavigate } from "../../utils/safeNavigate";

interface Props {
  project: Project;
  onClose: () => void;
  onEdit: () => void;
  onToggleTask: (taskId: string) => void;
}

export const ProjectViewModal: React.FC<Props> = ({ project, onClose, onEdit, onToggleTask }) => {
  return (
    <Modal title={project.name} onClose={onClose} width={520}>
      {project.notes && (
        <div className="field">
          <p style={{ fontSize: 13, color: "rgb(var(--text-secondary))", margin: 0, whiteSpace: "pre-wrap" }}>
            {project.notes}
          </p>
        </div>
      )}

      {project.resources.length > 0 && (
        <div className="field">
          <label style={{ marginBottom: 8, display: "block" }}>Resources</label>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {project.resources.map((r) => (
              <button
                key={r.id}
                className="board-row"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "8px 10px",
                  borderRadius: 8,
                  background: "transparent",
                  border: "none",
                  textAlign: "left",
                  cursor: "pointer",
                  width: "100%",
                  transition: "background var(--dur-fast) var(--ease-standard)"
                }}
                onClick={() => safeNavigate(r.url)}
                onKeyDown={(e) => e.key === "Enter" && safeNavigate(r.url)}
              >
                <span style={{ fontSize: 13, color: "rgb(var(--accent))", fontWeight: 500 }}>↗</span>
                <span style={{ fontSize: 13, color: "rgb(var(--text-primary))" }}>{r.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {project.tasks.length > 0 && (
        <div className="field">
          <label style={{ marginBottom: 8, display: "block" }}>Tasks</label>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {[...project.tasks].sort((a, b) => a.order - b.order).map((task) => (
              <label
                key={task.id}
                className="task-row"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "6px 8px",
                  borderRadius: 8,
                  cursor: "pointer",
                  transition: "background var(--dur-fast) var(--ease-standard)"
                }}
              >
                <input
                  type="checkbox"
                  checked={task.done}
                  onChange={() => onToggleTask(task.id)}
                  style={{ accentColor: "rgb(var(--accent))" }}
                />
                <span
                  className={task.done ? "task-row-label-done" : ""}
                  style={{
                    fontSize: 13,
                    color: task.done ? "rgb(var(--text-muted))" : "rgb(var(--text-primary))",
                    textDecoration: task.done ? "line-through" : "none"
                  }}
                >
                  {task.label}
                </span>
              </label>
            ))}
          </div>
        </div>
      )}

      {project.resources.length === 0 && project.tasks.length === 0 && !project.notes && (
        <div className="todo-empty" style={{ padding: "24px 8px", textAlign: "center", fontSize: 12, color: "rgb(var(--text-muted))" }}>
          This project has no resources, tasks, or notes yet.
        </div>
      )}

      <div className="btn-row">
        <button className="btn" onClick={onClose}>
          Close
        </button>
        <button className="btn btn-primary" onClick={onEdit}>
          ✎ Edit project
        </button>
      </div>
    </Modal>
  );
};
