import React, { useState } from "react";
import { ProjectTask } from "../../types";
import { createId } from "../../utils/id";
import "./task-list.css";

interface Props {
  tasks: ProjectTask[];
  onChange: (tasks: ProjectTask[]) => void;
}

export const TaskListEditor: React.FC<Props> = ({ tasks, onChange }) => {
  const [draft, setDraft] = useState("");
  const dragId = React.useRef<string | null>(null);

  const addTask = () => {
    const trimmed = draft.trim();
    if (!trimmed) return;
    onChange([...tasks, { id: createId(), label: trimmed, done: false, order: tasks.length, createdAt: Date.now() }]);
    setDraft("");
  };

  const toggleTask = (id: string) => onChange(tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  const removeTask = (id: string) => onChange(tasks.filter((t) => t.id !== id));

  const handleDrop = (targetId: string) => {
    if (!dragId.current || dragId.current === targetId) return;
    const ids = tasks.map((t) => t.id);
    const from = ids.indexOf(dragId.current);
    const to = ids.indexOf(targetId);
    if (from === -1 || to === -1) return;
    ids.splice(to, 0, ids.splice(from, 1)[0]);
    onChange(
      tasks
        .slice()
        .sort((a, b) => ids.indexOf(a.id) - ids.indexOf(b.id))
        .map((t, i) => ({ ...t, order: i }))
    );
    dragId.current = null;
  };

  const doneCount = tasks.filter((t) => t.done).length;

  return (
    <div className="task-editor">
      {tasks.length > 0 && (
        <div className="task-editor-progress">
          <div className="task-editor-progress-track">
            <div
              className="task-editor-progress-fill"
              style={{ width: tasks.length ? `${(doneCount / tasks.length) * 100}%` : "0%" }}
            />
          </div>
          <span className="field-hint">
            {doneCount} of {tasks.length} done
          </span>
        </div>
      )}

      <div className="task-editor-list">
        {tasks
          .slice()
          .sort((a, b) => a.order - b.order)
          .map((t) => (
            <div
              key={t.id}
              className="task-row"
              draggable
              onDragStart={() => (dragId.current = t.id)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => handleDrop(t.id)}
            >
              <label className="task-row-checkbox">
                <input type="checkbox" checked={t.done} onChange={() => toggleTask(t.id)} />
                <span className={`task-row-label ${t.done ? "task-row-label-done" : ""}`}>{t.label}</span>
              </label>
              <button type="button" className="icon-btn" onClick={() => removeTask(t.id)} aria-label={`Remove ${t.label}`}>
                ✕
              </button>
            </div>
          ))}
        {tasks.length === 0 && <p className="field-hint">No tasks yet — add the first thing to do below.</p>}
      </div>

      <div className="task-editor-add">
        <input
          type="text"
          placeholder="Add a task…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              addTask();
            }
          }}
        />
        <button type="button" className="btn" onClick={addTask}>
          Add
        </button>
      </div>
    </div>
  );
};
