import React, { useState } from "react";
import { useAppState } from "../../store/AppStateContext";
import { Project } from "../../types";
import { ProjectFormModal } from "./ProjectFormModal";
import { ProjectViewModal } from "./ProjectViewModal";
import { EmptyState } from "../common/EmptyState";
import { useToast } from "../common/Toast";
import "./projects.css";

interface Props {
  focusProjectId?: string | null;
  clearFocus?: () => void;
  openAddSignal?: number;
}

export const ProjectsPanel: React.FC<Props> = ({ focusProjectId, clearFocus, openAddSignal }) => {
  const { state, update } = useAppState();
  const { show } = useToast();
  const [viewProject, setViewProject] = useState<Project | null>(
    focusProjectId ? state.projects.find((p) => p.id === focusProjectId) ?? null : null
  );
  const [editProject, setEditProject] = useState<{ mode: "add" | "edit"; project?: Project } | null>(null);

  const lastSignal = React.useRef(openAddSignal);
  React.useEffect(() => {
    if (openAddSignal !== undefined && openAddSignal !== lastSignal.current) {
      lastSignal.current = openAddSignal;
      setEditProject({ mode: "add" });
    }
  }, [openAddSignal]);

  React.useEffect(() => {
    if (focusProjectId) {
      const p = state.projects.find((p) => p.id === focusProjectId);
      if (p) setViewProject(p);
      clearFocus?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusProjectId]);

  const persist = (projects: Project[]) => update((s) => ({ ...s, projects }));
  const projects = [...state.projects].sort((a, b) => a.order - b.order);

  if (projects.length === 0 && !editProject) {
    return (
      <EmptyState
        title="No projects yet"
        hint="Group applications, links, and notes into lightweight personal workspaces."
        action={{ label: "Create your first project", onClick: () => setEditProject({ mode: "add" }) }}
      />
    );
  }

  return (
    <div className="projects-panel scrollable">
      <div className="projects-grid">
        {projects.map((p) => {
          const doneCount = p.tasks?.filter((t) => t.done).length ?? 0;
          const totalTasks = p.tasks?.length ?? 0;
          return (
            <div key={p.id} className="project-card glass" style={{ position: "relative" }}>
              <button
                className="project-card-inner"
                onClick={() => setViewProject(p)}
                style={{
                  all: "unset",
                  display: "flex",
                  flexDirection: "column",
                  gap: 6,
                  width: "100%",
                  cursor: "pointer",
                  padding: "16px"
                }}
              >
                <span className="project-card-dot" style={{ background: p.color }} />
                <span className="project-card-name">{p.name}</span>
                {p.notes && <span className="project-card-notes">{p.notes}</span>}
                {totalTasks > 0 && (
                  <div className="project-card-progress">
                    <div className="project-card-progress-track">
                      <div
                        className="project-card-progress-fill"
                        style={{ width: `${(doneCount / totalTasks) * 100}%`, background: p.color }}
                      />
                    </div>
                    <span className="project-card-progress-label">
                      {doneCount}/{totalTasks} tasks
                    </span>
                  </div>
                )}
                <span className="project-card-count">
                  {p.resources.length} resource{p.resources.length === 1 ? "" : "s"}
                </span>
              </button>
              {/* Secondary edit button — visible on hover, keyboard accessible */}
              <button
                className="project-card-edit-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  setEditProject({ mode: "edit", project: p });
                }}
                aria-label={`Edit ${p.name}`}
                title="Edit project"
              >
                ✎
              </button>
            </div>
          );
        })}
        <button className="project-card project-card-add glass" onClick={() => setEditProject({ mode: "add" })}>
          <span className="project-card-add-plus">+</span>
          New project
        </button>
      </div>

      {/* View modal (primary click) */}
      {viewProject && (
        <ProjectViewModal
          project={viewProject}
          onClose={() => setViewProject(null)}
          onEdit={() => {
            setEditProject({ mode: "edit", project: viewProject });
            setViewProject(null);
          }}
          onToggleTask={(taskId) => {
            const updated = state.projects.map((p) =>
              p.id === viewProject.id
                ? { ...p, tasks: p.tasks.map((t) => (t.id === taskId ? { ...t, done: !t.done } : t)) }
                : p
            );
            persist(updated);
            // Update the view modal's project reference
            const refreshed = updated.find((p) => p.id === viewProject.id);
            if (refreshed) setViewProject(refreshed);
          }}
        />
      )}

      {/* Edit modal (secondary action) */}
      {editProject && (
        <ProjectFormModal
          initial={editProject.mode === "edit" ? editProject.project : undefined}
          onClose={() => setEditProject(null)}
          onSave={(project) => {
            const exists = state.projects.some((p) => p.id === project.id);
            persist(exists ? state.projects.map((p) => (p.id === project.id ? project : p)) : [...state.projects, project]);
            show(exists ? "Project updated" : "Project created");
            setEditProject(null);
          }}
          onDelete={(id) => {
            if (window.confirm("Delete this project?")) {
              persist(state.projects.filter((p) => p.id !== id));
              show("Project deleted");
              setEditProject(null);
            }
          }}
        />
      )}
    </div>
  );
};
