import React, { useState } from "react";
import { Project, ProjectResource, ProjectTask } from "../../types";
import { Modal } from "../common/Modal";
import { normalizeAppUrl } from "../../utils/url";
import { createId } from "../../utils/id";
import { TaskListEditor } from "./TaskListEditor";

const SWATCHES = ["#e8b968", "#5eb0be", "#8a5ea6", "#7abc8c", "#e0695e", "#6a7bc9"];

interface Props {
  initial?: Project;
  onClose: () => void;
  onSave: (project: Project) => void;
  onDelete?: (id: string) => void;
}

export const ProjectFormModal: React.FC<Props> = ({ initial, onClose, onSave, onDelete }) => {
  const [name, setName] = useState(initial?.name ?? "");
  const [color, setColor] = useState(initial?.color ?? SWATCHES[0]);
  const [notes, setNotes] = useState(initial?.notes ?? "");
  const [resources, setResources] = useState<ProjectResource[]>(initial?.resources ?? []);
  const [tasks, setTasks] = useState<ProjectTask[]>(initial?.tasks ?? []);
  const [resLabel, setResLabel] = useState("");
  const [resUrl, setResUrl] = useState("");
  const [error, setError] = useState<string | undefined>();

  const addResource = () => {
    const url = normalizeAppUrl(resUrl);
    if (!resLabel.trim() || !url) return;
    setResources((prev) => [...prev, { id: createId(), label: resLabel.trim(), url }]);
    setResLabel("");
    setResUrl("");
  };

  const handleSave = () => {
    const trimmed = name.trim();
    if (!trimmed) {
      setError("Project name is required.");
      return;
    }
    onSave({
      id: initial?.id ?? createId(),
      name: trimmed,
      color,
      notes,
      resources,
      tasks,
      order: initial?.order ?? Date.now(),
      createdAt: initial?.createdAt ?? Date.now()
    });
  };

  return (
    <Modal title={initial ? "Edit project" : "New project"} onClose={onClose} width={520}>
      <div className="field">
        <label htmlFor="proj-name">Project name</label>
        <input id="proj-name" type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Cybersecurity Lab" />
        {error && <span className="field-error">{error}</span>}
      </div>

      <div className="field">
        <label>Color</label>
        <div style={{ display: "flex", gap: 8 }}>
          {SWATCHES.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setColor(c)}
              aria-label={`Color ${c}`}
              aria-pressed={color === c}
              style={{
                width: 26,
                height: 26,
                borderRadius: "50%",
                background: c,
                border: color === c ? "2px solid white" : "2px solid transparent",
                cursor: "pointer"
              }}
            />
          ))}
        </div>
      </div>

      <div className="field">
        <label htmlFor="proj-notes">Notes</label>
        <textarea
          id="proj-notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          placeholder="What's this workspace for?"
        />
      </div>

      <div className="field">
        <label>Tasks</label>
        <TaskListEditor tasks={tasks} onChange={setTasks} />
      </div>

      <div className="field">
        <label>Resources</label>
        {resources.map((r) => (
          <div key={r.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "4px 0" }}>
            <span style={{ flex: 1, fontSize: 13 }}>{r.label}</span>
            <button
              type="button"
              className="icon-btn"
              onClick={() => setResources((prev) => prev.filter((x) => x.id !== r.id))}
              aria-label={`Remove ${r.label}`}
            >
              ✕
            </button>
          </div>
        ))}
        <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
          <input
            type="text"
            placeholder="Label"
            value={resLabel}
            onChange={(e) => setResLabel(e.target.value)}
            style={{ flex: 1 }}
          />
          <input
            type="text"
            placeholder="URL"
            value={resUrl}
            onChange={(e) => setResUrl(e.target.value)}
            style={{ flex: 1 }}
          />
          <button type="button" className="btn" onClick={addResource}>
            Add
          </button>
        </div>
      </div>

      <div className="btn-row">
        {initial && onDelete && (
          <button className="btn btn-danger" style={{ marginRight: "auto" }} onClick={() => onDelete(initial.id)}>
            Delete
          </button>
        )}
        <button className="btn" onClick={onClose}>
          Cancel
        </button>
        <button className="btn btn-primary" onClick={handleSave}>
          Save project
        </button>
      </div>
    </Modal>
  );
};
