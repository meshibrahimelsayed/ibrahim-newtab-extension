import React, { useEffect, useMemo, useRef, useState } from "react";
import { AppItem, Category, Project, SavedItem } from "../../types";
import { savedAsApp } from "../../services/saved/savedStore";
import { hostnameOf } from "../../utils/url";
import { AppIcon } from "../applications/AppIcon";
import { safeNavigate } from "../../utils/safeNavigate";
import "./search.css";

interface Result {
  id: string;
  kind: "app" | "project" | "saved" | "web";
  label: string;
  sublabel: string;
  onSelect: () => void;
  icon?: React.ReactNode;
}

interface Props {
  apps: AppItem[];
  categories: Category[];
  projects: Project[];
  saved: SavedItem[];
  onOpenProject: (id: string) => void;
}

export const GlobalSearch: React.FC<Props> = ({ apps, categories, projects, saved, onOpenProject }) => {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        inputRef.current?.focus();
        setOpen(true);
      }
      const el = document.activeElement as HTMLElement | null;
      const typing = !!el && (["INPUT", "TEXTAREA", "SELECT"].includes(el.tagName) || el.isContentEditable);
      if (e.key === "/" && !typing) {
        e.preventDefault();
        inputRef.current?.focus();
        setOpen(true);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    const onClickAway = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClickAway);
    return () => document.removeEventListener("mousedown", onClickAway);
  }, []);

  const results: Result[] = useMemo(() => {
    const q = query.trim().toLowerCase();
    const catName = (id: string) => categories.find((c) => c.id === id)?.name ?? "";

    const appResults: Result[] = apps
      .filter((a) => !q || a.name.toLowerCase().includes(q) || hostnameOf(a.url).includes(q))
      .slice(0, 8)
      .map((a) => ({
        id: `app-${a.id}`,
        kind: "app",
        label: a.name,
        sublabel: catName(a.categoryId),
        icon: <AppIcon app={a} size={22} />,
        onSelect: () => {
          safeNavigate(a.url);
        }
      }));

    const savedResults: Result[] = q
      ? saved
          .filter((i) => i.title.toLowerCase().includes(q) || i.url.toLowerCase().includes(q))
          .slice(0, 5)
          .map((i) => ({
            id: `saved-${i.id}`,
            kind: "saved" as const,
            label: i.title,
            sublabel: "Saved",
            icon: <AppIcon app={savedAsApp(i)} size={22} />,
            onSelect: () => {
              safeNavigate(i.url);
            }
          }))
      : [];

    const projectResults: Result[] = projects
      .filter((p) => q && p.name.toLowerCase().includes(q))
      .slice(0, 4)
      .map((p) => ({
        id: `proj-${p.id}`,
        kind: "project",
        label: p.name,
        sublabel: "Project",
        onSelect: () => onOpenProject(p.id)
      }));

    const webResult: Result[] =
      q.length > 0
        ? [
            {
              id: "web-search",
              kind: "web",
              label: `Search Google for "${query.trim()}"`,
              sublabel: "Google Search",
              icon: (
                <svg width="18" height="18" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"/>
                  <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"/>
                  <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.14-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"/>
                  <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
                </svg>
              ),
              onSelect: () => {
                safeNavigate(`https://www.google.com/search?q=${encodeURIComponent(query.trim())}`);
              }
            }
          ]
        : [];

    return [...appResults, ...savedResults, ...projectResults, ...webResult];
  }, [query, apps, categories, projects, saved, onOpenProject]);

  useEffect(() => setActiveIdx(0), [query]);

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIdx((i) => Math.min(i + 1, results.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIdx((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (results[activeIdx]) {
        results[activeIdx].onSelect();
      } else if (query.trim()) {
        safeNavigate(`https://www.google.com/search?q=${encodeURIComponent(query.trim())}`);
      }
    } else if (e.key === "Escape") {
      setOpen(false);
      inputRef.current?.blur();
    }
  };

  const handleGoogleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (query.trim()) {
      safeNavigate(`https://www.google.com/search?q=${encodeURIComponent(query.trim())}`);
    } else {
      inputRef.current?.focus();
    }
  };

  const showResults = open && (query.length > 0 || results.length > 0);

  return (
    <div className="search-root" ref={rootRef}>
      <div className={`search-bar glass ${open ? "search-bar-focused" : ""}`} onClick={() => inputRef.current?.focus()}>
        <svg className="search-lens-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2.2" />
          <path d="m20 20-3.5-3.5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
        </svg>
        <input
          ref={inputRef}
          type="text"
          value={query}
          placeholder="Search..."
          aria-label="Global search"
          role="combobox"
          aria-expanded={showResults}
          aria-controls="search-results"
          onFocus={() => setOpen(true)}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={onKeyDown}
        />
        <div className="search-google-badge" onClick={handleGoogleClick} title="Google Search">
          <svg width="18" height="18" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"/>
            <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"/>
            <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.14-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"/>
            <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
          </svg>
        </div>
      </div>
      {showResults && (
        <div className="search-results glass scrollable" id="search-results" role="listbox">
          {results.length === 0 ? (
            <div className="search-empty">No matches. Press Enter to search Google.</div>
          ) : (
            results.map((r, i) => (
              <button
                key={r.id}
                role="option"
                aria-selected={i === activeIdx}
                className={`search-result ${i === activeIdx ? "search-result-active" : ""}`}
                onMouseEnter={() => setActiveIdx(i)}
                onClick={r.onSelect}
              >
                <span className="search-result-icon">
                  {r.icon ?? (r.kind === "web" ? "⌕" : r.kind === "project" ? "▤" : "•")}
                </span>
                <span className="search-result-text">
                  <span className="search-result-label">{r.label}</span>
                  <span className="search-result-sub">{r.sublabel}</span>
                </span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
};
