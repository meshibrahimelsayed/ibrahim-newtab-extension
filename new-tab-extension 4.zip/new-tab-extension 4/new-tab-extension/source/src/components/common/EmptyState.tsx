import React from "react";
import "./empty-state.css";

interface Props {
  title: string;
  hint?: string;
  action?: { label: string; onClick: () => void };
}

export const EmptyState: React.FC<Props> = ({ title, hint, action }) => (
  <div className="empty-state">
    <p className="empty-state-title">{title}</p>
    {hint && <p className="empty-state-hint">{hint}</p>}
    {action && (
      <button className="btn btn-primary" onClick={action.onClick}>
        {action.label}
      </button>
    )}
  </div>
);
