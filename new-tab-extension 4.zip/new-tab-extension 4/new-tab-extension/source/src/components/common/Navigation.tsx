import React from "react";
import "./navigation.css";

export type View = "home" | "saved" | "projects";

interface Props {
  view: View;
  onChangeView: (v: View) => void;
  onPlus: () => void;
  savedCount: number;
}

const TABS: { id: View; label: string; hint: string }[] = [
  { id: "home", label: "Home", hint: "Alt+1" },
  { id: "saved", label: "Saved", hint: "Alt+2" },
  { id: "projects", label: "Projects", hint: "Alt+3" }
];

export const Navigation: React.FC<Props> = ({ view, onChangeView, onPlus, savedCount }) => (
  <nav className="nav-bar" aria-label="Views">
    <div className="nav-tabs glass">
      {TABS.map((t) => (
        <button
          key={t.id}
          className={`nav-tab ${view === t.id ? "nav-tab-active" : ""}`}
          onClick={() => onChangeView(t.id)}
          title={t.hint}
          aria-current={view === t.id ? "page" : undefined}
        >
          {t.label}
          {t.id === "saved" && savedCount > 0 && <span className="nav-badge">{savedCount > 99 ? "99+" : savedCount}</span>}
        </button>
      ))}
      {view !== "saved" && (
        <button
          className="nav-tab nav-tab-plus"
          onClick={onPlus}
          aria-label={view === "home" ? "Add application" : "New project"}
          title={view === "home" ? "Add application" : "New project"}
        >
          +
        </button>
      )}
    </div>
  </nav>
);
