import React, { useEffect, useState } from "react";
import { ACTIONS, comboFromEvent, prettyCombo, resetBindings, setBinding, useBindings } from "../../services/shortcuts/shortcuts";
import "./shortcuts.css";

const CHROME: [string, string][] = [
  ["Ctrl + T", "Open a new tab"], ["Ctrl + W", "Close the current tab"], ["Ctrl + Shift + T", "Reopen the last closed tab"],
  ["Ctrl + Tab", "Next tab"], ["Ctrl + 1 … 8", "Jump to a tab by position"], ["Ctrl + L", "Focus the address bar"],
  ["Ctrl + D", "Bookmark the current page in Chrome"], ["Ctrl + Shift + B", "Show / hide the bookmarks bar"],
  ["Ctrl + Shift + A", "Search through open tabs"], ["Ctrl + F", "Find on page"], ["Ctrl + Shift + Del", "Clear browsing data"]
];

const Keys: React.FC<{ combo: string }> = ({ combo }) => (
  <span className="keys-combo">{prettyCombo(combo).map((k, i) => <kbd key={i}>{k}</kbd>)}</span>
);

export const ShortcutsDialog: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const b = useBindings();
  const [recording, setRecording] = useState<string | null>(null);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (recording) {
        e.preventDefault();
        e.stopImmediatePropagation();
        if (e.key === "Escape") return setRecording(null);
        const combo = comboFromEvent(e);
        if (!combo) return;
        const err = setBinding(recording, combo);
        setMsg(err ?? "");
        if (!err) setRecording(null);
      } else if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [recording, onClose]);

  const openChromeShortcuts = () => typeof chrome !== "undefined" && chrome.tabs?.create({ url: "chrome://extensions/shortcuts" });

  return (
    <div className="keys-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()} role="presentation">
      <div className="keys-dialog" role="dialog" aria-modal="true" aria-labelledby="keys-title">
        <header>
          <h2 id="keys-title">Keyboard shortcuts</h2>
          <button className="keys-x" onClick={onClose} aria-label="Close">✕</button>
        </header>
        <div className="keys-scroll">
          <section>
            <h3>New Tab <span>click “Change”, then press the keys you want</span></h3>
            {ACTIONS.map((a) => (
              <div className="keys-row" key={a.id}>
                <div><strong>{a.label}</strong><small>{a.hint}</small></div>
                {recording === a.id ? <em className="keys-rec">Press keys… (Esc to cancel)</em> : <Keys combo={b[a.id]} />}
                <button onClick={() => { setMsg(""); setRecording(recording === a.id ? null : a.id); }}>Change</button>
              </div>
            ))}
            <div className="keys-row">
              <div><strong>Search</strong><small>Search bookmarks, saved tabs and projects</small></div>
              <span className="keys-combo"><kbd>/</kbd><kbd>Ctrl</kbd><kbd>K</kbd></span><span />
            </div>
            {msg && <p className="keys-msg" role="alert">{msg}</p>}
            <button className="keys-link" onClick={resetBindings}>Reset to defaults</button>
          </section>
          <section>
            <h3>Extension <span>works on any page</span></h3>
            <div className="keys-row">
              <div><strong>Save current tab</strong><small>Adds it to Saved. Also: toolbar icon or right-click → Save to New Tab</small></div>
              <Keys combo="Alt+Shift+KeyS" />
              <button onClick={openChromeShortcuts}>Change in Chrome</button>
            </div>
          </section>
          <section>
            <h3>Chrome <span>built in (use ⌘ instead of Ctrl on Mac)</span></h3>
            {CHROME.map(([k, d]) => (
              <div className="keys-row" key={k}><div><strong>{d}</strong></div><span className="keys-combo">{k.split(" + ").map((x) => <kbd key={x}>{x}</kbd>)}</span><span /></div>
            ))}
          </section>
        </div>
      </div>
    </div>
  );
};
