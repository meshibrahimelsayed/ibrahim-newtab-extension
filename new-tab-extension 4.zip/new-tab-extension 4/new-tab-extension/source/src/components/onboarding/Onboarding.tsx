import React, { useState } from "react";
import { useAppState } from "../../store/AppStateContext";
import "./onboarding.css";

const ACCENTS = ["#e8b968", "#5eb0be", "#8a5ea6", "#7abc8c"];

export const Onboarding: React.FC<{ onDone: () => void }> = ({ onDone }) => {
  const { update } = useAppState();
  const [step, setStep] = useState(0);
  const [theme, setTheme] = useState<"dark" | "light" | "auto">("auto");
  const [accent, setAccent] = useState(ACCENTS[0]);
  const [weatherEnabled, setWeatherEnabled] = useState(true);

  const finish = () => {
    update((s) => ({
      ...s,
      settings: {
        ...s.settings,
        appearance: { ...s.settings.appearance, theme, accent },
        weather: { ...s.settings.weather, enabled: weatherEnabled },
        onboardingComplete: true
      }
    }));
    onDone();
  };

  const steps = [
    {
      title: "Welcome to New Tab",
      body: (
        <p className="onboarding-body">A calm, cinematic new tab. Let's set a few preferences — it only takes a moment.</p>
      )
    },
    {
      title: "Choose a theme",
      body: (
        <div className="onboarding-choices">
          {(["dark", "light", "auto"] as const).map((t) => (
            <button
              key={t}
              className={`onboarding-choice ${theme === t ? "onboarding-choice-active" : ""}`}
              onClick={() => setTheme(t)}
            >
              {t[0].toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>
      )
    },
    {
      title: "Pick an accent color",
      body: (
        <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
          {ACCENTS.map((c) => (
            <button
              key={c}
              onClick={() => setAccent(c)}
              aria-pressed={accent === c}
              style={{
                width: 36,
                height: 36,
                borderRadius: "50%",
                background: c,
                border: accent === c ? "2px solid white" : "2px solid transparent"
              }}
            />
          ))}
        </div>
      )
    },
    {
      title: "Enable weather?",
      body: (
        <div className="onboarding-choices">
          <button
            className={`onboarding-choice ${weatherEnabled ? "onboarding-choice-active" : ""}`}
            onClick={() => setWeatherEnabled(true)}
          >
            Yes, show weather
          </button>
          <button
            className={`onboarding-choice ${!weatherEnabled ? "onboarding-choice-active" : ""}`}
            onClick={() => setWeatherEnabled(false)}
          >
            No thanks
          </button>
        </div>
      )
    }
  ];

  const isLast = step === steps.length - 1;

  return (
    <div className="onboarding-overlay">
      <div className="onboarding-card glass">
        <h2 className="onboarding-title">{steps[step].title}</h2>
        {steps[step].body}
        <div className="onboarding-progress">
          {steps.map((_, i) => (
            <span key={i} className={`onboarding-dot ${i === step ? "onboarding-dot-active" : ""}`} />
          ))}
        </div>
        <div className="onboarding-actions">
          {step > 0 && (
            <button className="btn" onClick={() => setStep((s) => s - 1)}>
              Back
            </button>
          )}
          <button className="btn btn-primary" onClick={() => (isLast ? finish() : setStep((s) => s + 1))}>
            {isLast ? "Start using New Tab" : "Continue"}
          </button>
        </div>
      </div>
    </div>
  );
};
