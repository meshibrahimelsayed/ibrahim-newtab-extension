import React, { useEffect } from "react";
import { useAppState } from "../../store/AppStateContext";
import { Category } from "../../types";
import "./arrange.css";

/** Precise ordering for bookmark cards: move up/down/top/bottom, or sort in one click. */
export const ArrangeDialog: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { state, update } = useAppState();
  const cats = [...state.categories].sort((a, b) => a.order - b.order);
  const count = (id: string) => state.apps.filter((a) => a.categoryId === id).length;

  useEffect(() => {
    const esc = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onClose]);

  const apply = (ids: string[]) =>
    update((s) => ({ ...s, categories: s.categories.map((c) => ({ ...c, order: ids.indexOf(c.id) })) }));
  const move = (from: number, to: number) => {
    if (to < 0 || to >= cats.length || to === from) return;
    const ids = cats.map((c) => c.id);
    ids.splice(to, 0, ids.splice(from, 1)[0]);
    apply(ids);
  };
  const sortBy = (cmp: (a: Category, b: Category) => number) => apply([...cats].sort(cmp).map((c) => c.id));

  return (
    <div className="arr-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()} role="presentation">
      <div className="arr-dialog" role="dialog" aria-modal="true" aria-labelledby="arr-title">
        <header>
          <h2 id="arr-title">Arrange cards</h2>
          <button className="arr-x" onClick={onClose} aria-label="Close">✕</button>
        </header>
        <p className="arr-hint">Cards fill the screen column by column: the first ones run down the first column, then the next.</p>
        <div className="arr-sorts">
          <button onClick={() => sortBy((a, b) => a.name.localeCompare(b.name))}>A → Z</button>
          <button onClick={() => sortBy((a, b) => count(b.id) - count(a.id))}>Most bookmarks first</button>
          <button onClick={() => sortBy((a, b) => b.createdAt - a.createdAt)}>Newest first</button>
        </div>
        <ol className="arr-list">
          {cats.map((c, i) => (
            <li key={c.id}>
              <span className="arr-n">{i + 1}</span>
              <span className="arr-name">{c.name}</span>
              <span className="arr-count">{count(c.id)}</span>
              <button onClick={() => move(i, 0)} disabled={i === 0} aria-label={`Move ${c.name} to top`} title="To top">⤒</button>
              <button onClick={() => move(i, i - 1)} disabled={i === 0} aria-label={`Move ${c.name} up`} title="Up">▲</button>
              <button onClick={() => move(i, i + 1)} disabled={i === cats.length - 1} aria-label={`Move ${c.name} down`} title="Down">▼</button>
              <button onClick={() => move(i, cats.length - 1)} disabled={i === cats.length - 1} aria-label={`Move ${c.name} to bottom`} title="To bottom">⤓</button>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
};
