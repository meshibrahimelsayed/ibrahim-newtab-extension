import React, { useEffect, useRef, useState } from "react";
import "./bottombar.css";
import { DEFAULT_PREFS, setPrefs, usePrefs } from "../../store/prefsStore";

/** Bottom-bar button with sliders for bookmark card width and text size. */
export const CardSizeControl: React.FC = () => {
  const p = usePrefs();
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent) => !box.current?.contains(e.target as Node) && setOpen(false);
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", away);
    document.addEventListener("keydown", esc);
    return () => { document.removeEventListener("mousedown", away); document.removeEventListener("keydown", esc); };
  }, [open]);

  return (
    <div className="size-ctl" ref={box}>
      <button className="fab-btn" onClick={() => setOpen((o) => !o)} title="Card size" aria-label="Card size" aria-expanded={open}>▦</button>
      {open && (
        <div className="size-pop" role="dialog" aria-label="Card size">
          <label>Card width <span>{p.cardWidth}px</span>
            <input type="range" min={190} max={460} step={10} value={p.cardWidth} onChange={(e) => setPrefs({ cardWidth: +e.target.value })} />
          </label>
          <label>Text size <span>{Math.round(p.rowScale * 100)}%</span>
            <input type="range" min={0.85} max={1.35} step={0.05} value={p.rowScale} onChange={(e) => setPrefs({ rowScale: +e.target.value })} />
          </label>
          <button onClick={() => setPrefs(DEFAULT_PREFS)}>Reset</button>
        </div>
      )}
    </div>
  );
};
