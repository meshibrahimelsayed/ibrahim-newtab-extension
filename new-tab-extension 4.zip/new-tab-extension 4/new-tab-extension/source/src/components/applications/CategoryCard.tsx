import React, { useState } from "react";
import { AppItem, Category } from "../../types";
import { AppIcon } from "./AppIcon";
import { ContextMenu, ContextMenuItem } from "../common/ContextMenu";
import { safeNavigate } from "../../utils/safeNavigate";
import "./category-card.css";

interface Props {
  category: Category | { id: "favorites"; name: string };
  apps: AppItem[];
  categories: Category[];
  isFavoritesCard?: boolean;
  onEdit: (app: AppItem) => void;
  onDelete: (id: string) => void;
  onDuplicate: (app: AppItem) => void;
  onToggleFavorite: (id: string) => void;
  onMoveToCategory: (id: string, categoryId: string) => void;
  onReorderWithin: (categoryId: string, orderedIds: string[]) => void;
  onAddApp: (categoryId: string) => void;
  onRenameCategory?: (id: string, name: string) => void;
  onDeleteCategory?: (id: string) => void;
  dragHandleProps?: {
    draggable: boolean;
    onDragStart: () => void;
    onDragOver: (e: React.DragEvent) => void;
    onDrop: () => void;
  };
}

export const CategoryCard: React.FC<Props> = ({
  category,
  apps,
  categories,
  isFavoritesCard,
  onEdit,
  onDelete,
  onDuplicate,
  onToggleFavorite,
  onMoveToCategory,
  onReorderWithin,
  onAddApp,
  onRenameCategory,
  onDeleteCategory,
  dragHandleProps
}) => {
  const [menu, setMenu] = useState<{ x: number; y: number; app: AppItem } | null>(null);
  const [renaming, setRenaming] = useState(false);
  const [renameDraft, setRenameDraft] = useState(category.name);
  const dragAppId = React.useRef<string | null>(null);

  const handleRowDrop = (targetId: string) => {
    if (!dragAppId.current || dragAppId.current === targetId) return;
    const ids = apps.map((a) => a.id);
    const from = ids.indexOf(dragAppId.current);
    const to = ids.indexOf(targetId);
    if (from === -1 || to === -1) return;
    ids.splice(to, 0, ids.splice(from, 1)[0]);
    onReorderWithin(category.id, ids);
    dragAppId.current = null;
  };

  const commitRename = () => {
    const trimmed = renameDraft.trim();
    if (trimmed && onRenameCategory) onRenameCategory(category.id, trimmed);
    setRenaming(false);
  };

  const menuItems: ContextMenuItem[] = menu
    ? [
        { label: "Open", onSelect: () => safeNavigate(menu.app.url) },
        { label: "Edit", onSelect: () => onEdit(menu.app) },
        {
          label: menu.app.favorite ? "Remove from favorites" : "Add to favorites",
          onSelect: () => onToggleFavorite(menu.app.id)
        },
        { label: "Duplicate", onSelect: () => onDuplicate(menu.app) },
        ...categories
          .filter((c) => c.id !== menu.app.categoryId)
          .map((c) => ({ label: `Move to ${c.name}`, onSelect: () => onMoveToCategory(menu.app.id, c.id) })),
        {
          label: "Delete",
          danger: true,
          onSelect: () => {
            if (window.confirm(`Delete "${menu.app.name}"?`)) onDelete(menu.app.id);
          }
        }
      ]
    : [];

  return (
    <div className="board-card" {...(dragHandleProps ? { draggable: dragHandleProps.draggable } : {})}
      onDragStart={dragHandleProps?.onDragStart}
      onDragOver={dragHandleProps?.onDragOver}
      onDrop={dragHandleProps?.onDrop}
    >
      <div className="board-card-header">
        {renaming ? (
          <input
            className="board-card-rename-input"
            value={renameDraft}
            autoFocus
            onChange={(e) => setRenameDraft(e.target.value)}
            onBlur={commitRename}
            onKeyDown={(e) => {
              if (e.key === "Enter") commitRename();
              if (e.key === "Escape") setRenaming(false);
            }}
          />
        ) : (
          <h3
            className="board-card-title"
            onDoubleClick={() => {
              if (onRenameCategory) {
                setRenameDraft(category.name);
                setRenaming(true);
              }
            }}
          >
            {isFavoritesCard && <span aria-hidden="true">★ </span>}
            {category.name}
          </h3>
        )}
        {onDeleteCategory && (
          <button
            className="board-card-delete"
            aria-label={`Delete ${category.name} category`}
            onClick={() => {
              if (window.confirm(`Delete category "${category.name}"? Its applications will also be removed.`)) {
                onDeleteCategory(category.id);
              }
            }}
          >
            ✕
          </button>
        )}
      </div>

      <div className="board-card-rows">
        {apps.map((app) => (
          <div
            key={app.id}
            className="board-row"
            draggable={!isFavoritesCard}
            onDragStart={() => (dragAppId.current = app.id)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => handleRowDrop(app.id)}
            onClick={() => safeNavigate(app.url)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === "Enter" && safeNavigate(app.url)}
            onContextMenu={(e) => {
              e.preventDefault();
              setMenu({ x: e.clientX, y: e.clientY, app });
            }}
          >
            <span className="board-row-icon">
              <AppIcon app={app} size={17} />
            </span>
            <span className="board-row-name">{app.name}</span>
          </div>
        ))}
        {apps.length === 0 && <div className="board-card-empty">No apps yet</div>}
      </div>

      {!isFavoritesCard && (
        <button className="board-card-add" onClick={() => onAddApp(category.id)}>
          + Add
        </button>
      )}

      {menu && <ContextMenu x={menu.x} y={menu.y} items={menuItems} onClose={() => setMenu(null)} />}
    </div>
  );
};
