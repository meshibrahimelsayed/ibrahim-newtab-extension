import React, { useState } from "react";
import { AppItem } from "../../types";
import { faviconUrlFor, monogramColorFor, monogramLetters, hostnameOf } from "../../utils/url";
import { useAppState } from "../../store/AppStateContext";

interface Props {
  app: AppItem;
  size?: number;
}

// Global cache of domain hostnames that returned 404 / error from favicon service.
// Avoids making repeated 404 network requests in the browser console.
const failedDomains = new Set<string>();

/**
 * Icon resolution chain:
 * 1. Custom uploaded icon (data URL)
 * 2. High-res site favicon (when allowed and domain hasn't failed previously)
 * 3. Local Monogram avatar (no network request)
 */
export const AppIcon: React.FC<Props> = ({ app, size = 26 }) => {
  const { state } = useAppState();
  const [faviconFailed, setFaviconFailed] = useState(false);
  const style: React.CSSProperties = { width: size, height: size };

  const domain = hostnameOf(app.url);

  // Custom uploaded icon — data URL
  if (app.iconType === "custom" && app.iconValue) {
    return <img src={app.iconValue} alt="" style={{ ...style, borderRadius: 6, objectFit: "cover" }} />;
  }

  // Check if favicon fetching is allowed and domain has not previously failed
  const allowGoogle = state.settings.appearance.allowGoogleFavicons;
  const shouldTryFavicon = (app.iconType === "favicon" || allowGoogle) && !failedDomains.has(domain);
  const favicon = shouldTryFavicon ? faviconUrlFor(app.url) : null;

  const handleImageError = () => {
    if (domain) {
      failedDomains.add(domain);
    }
    setFaviconFailed(true);
  };

  if (favicon && !faviconFailed) {
    return (
      <img
        src={favicon}
        alt=""
        style={{ ...style, borderRadius: 6, objectFit: "contain" }}
        onError={handleImageError}
      />
    );
  }

  // Deterministic monogram avatar fallback
  const letters = monogramLetters(app.name);
  const bgColor = monogramColorFor(app.name);
  return (
    <div
      style={{
        ...style,
        borderRadius: 6,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: bgColor,
        color: "#fff",
        fontSize: size * 0.42,
        fontWeight: 700,
        letterSpacing: letters.length > 1 ? "-0.02em" : undefined,
        lineHeight: 1,
        userSelect: "none"
      }}
      aria-hidden="true"
    >
      {letters}
    </div>
  );
};
