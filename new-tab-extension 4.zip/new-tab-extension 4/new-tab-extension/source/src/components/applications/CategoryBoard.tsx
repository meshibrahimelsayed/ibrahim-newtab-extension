import React, { useState } from "react";
import { useAppState } from "../../store/AppStateContext";
import { CategoryCard } from "./CategoryCard";
import { AppFormModal } from "./AppFormModal";
import { AppItem } from "../../types";
import { createId } from "../../utils/id";
import { useToast } from "../common/Toast";
import { EmptyState } from "../common/EmptyState";
import "./category-card.css";

interface Props {
  openAddSignal?: number;
}

export const CategoryBoard: React.FC<Props> = ({ openAddSignal }) => {
  const { state, update } = useAppState();
  const { show } = useToast();
  const [modal, setModal] = useState<{ mode: "add" | "edit"; app?: AppItem; defaultCategoryId?: string } | null>(null);
  const [addingCategory, setAddingCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState("");
  const dragCatId = React.useRef<string | null>(null);

  const lastSignal = React.useRef(openAddSignal);
  React.useEffect(() => {
    if (openAddSignal !== undefined && openAddSignal !== lastSignal.current) {
      lastSignal.current = openAddSignal;
      setModal({ mode: "add" });
    }
  }, [openAddSignal]);

  const persistApps = (apps: AppItem[]) => update((s) => ({ ...s, apps }));
  const categories = [...state.categories].sort((a, b) => a.order - b.order);
  const favorites = state.apps.filter((a) => a.favorite).sort((a, b) => a.order - b.order);

  const appsFor = (categoryId: string) =>
    state.apps.filter((a) => a.categoryId === categoryId).sort((a, b) => a.order - b.order);

  const commitAddCategory = () => {
    const trimmed = newCategoryName.trim();
    if (trimmed) {
      update((s) => ({
        ...s,
        categories: [...s.categories, { id: createId(), name: trimmed, order: s.categories.length, createdAt: Date.now() }]
      }));
    }
    setNewCategoryName("");
    setAddingCategory(false);
  };

  const handleCategoryDrop = (targetId: string) => {
    if (!dragCatId.current || dragCatId.current === targetId) return;
    const ids = categories.map((c) => c.id);
    const from = ids.indexOf(dragCatId.current);
    const to = ids.indexOf(targetId);
    if (from === -1 || to === -1) return;
    ids.splice(to, 0, ids.splice(from, 1)[0]);
    update((s) => ({ ...s, categories: s.categories.map((c) => ({ ...c, order: ids.indexOf(c.id) })) }));
    dragCatId.current = null;
  };

  if (state.apps.length === 0 && categories.length === 0) {
    return (
      <EmptyState
        title="No applications yet"
        hint="Add the sites and tools you use every day for one-click access."
        action={{ label: "Add your first application", onClick: () => setModal({ mode: "add" }) }}
      />
    );
  }

  return (
    <div className="category-board">
      {favorites.length > 0 && (
        <CategoryCard
          category={{ id: "favorites", name: "Favorites" }}
          apps={favorites}
          categories={categories}
          isFavoritesCard
          onEdit={(app) => setModal({ mode: "edit", app })}
          onDelete={(id) => {
            persistApps(state.apps.filter((a) => a.id !== id));
            show("Application removed");
          }}
          onDuplicate={(app) =>
            persistApps([...state.apps, { ...app, id: createId(), name: `${app.name} copy`, order: state.apps.length, createdAt: Date.now() }])
          }
          onToggleFavorite={(id) => persistApps(state.apps.map((a) => (a.id === id ? { ...a, favorite: !a.favorite } : a)))}
          onMoveToCategory={(id, categoryId) => persistApps(state.apps.map((a) => (a.id === id ? { ...a, categoryId } : a)))}
          onReorderWithin={() => {}}
          onAddApp={() => {}}
        />
      )}

      {categories.map((cat) => (
        <CategoryCard
          key={cat.id}
          category={cat}
          apps={appsFor(cat.id)}
          categories={categories}
          onEdit={(app) => setModal({ mode: "edit", app })}
          onDelete={(id) => {
            persistApps(state.apps.filter((a) => a.id !== id));
            show("Application removed");
          }}
          onDuplicate={(app) =>
            persistApps([...state.apps, { ...app, id: createId(), name: `${app.name} copy`, order: state.apps.length, createdAt: Date.now() }])
          }
          onToggleFavorite={(id) => persistApps(state.apps.map((a) => (a.id === id ? { ...a, favorite: !a.favorite } : a)))}
          onMoveToCategory={(id, categoryId) => persistApps(state.apps.map((a) => (a.id === id ? { ...a, categoryId } : a)))}
          onReorderWithin={(categoryId, orderedIds) =>
            persistApps(
              state.apps
                .map((a) => a)
                .sort((a, b) => {
                  if (a.categoryId !== categoryId || b.categoryId !== categoryId) return 0;
                  return orderedIds.indexOf(a.id) - orderedIds.indexOf(b.id);
                })
                .map((a) => (a.categoryId === categoryId ? { ...a, order: orderedIds.indexOf(a.id) } : a))
            )
          }
          onAddApp={(categoryId) => setModal({ mode: "add", defaultCategoryId: categoryId })}
          onRenameCategory={(id, name) =>
            update((s) => ({ ...s, categories: s.categories.map((c) => (c.id === id ? { ...c, name } : c)) }))
          }
          onDeleteCategory={(id) => {
            update((s) => ({
              ...s,
              categories: s.categories.filter((c) => c.id !== id),
              apps: s.apps.filter((a) => a.categoryId !== id)
            }));
            show("Category deleted");
          }}
          dragHandleProps={{
            draggable: true,
            onDragStart: () => (dragCatId.current = cat.id),
            onDragOver: (e) => e.preventDefault(),
            onDrop: () => handleCategoryDrop(cat.id)
          }}
        />
      ))}

      {addingCategory ? (
        <input
          className="board-card-new-input"
          autoFocus
          placeholder="Category name"
          value={newCategoryName}
          onChange={(e) => setNewCategoryName(e.target.value)}
          onBlur={commitAddCategory}
          onKeyDown={(e) => {
            if (e.key === "Enter") commitAddCategory();
            if (e.key === "Escape") setAddingCategory(false);
          }}
        />
      ) : (
        <button className="board-card-new" onClick={() => setAddingCategory(true)}>
          + New category
        </button>
      )}

      {modal && (
        <AppFormModal
          categories={state.categories}
          initial={modal.mode === "edit" ? modal.app : undefined}
          defaultCategoryId={modal.defaultCategoryId}
          onClose={() => setModal(null)}
          onSave={(app) => {
            const exists = state.apps.some((a) => a.id === app.id);
            persistApps(exists ? state.apps.map((a) => (a.id === app.id ? app : a)) : [...state.apps, app]);
            show(exists ? "Application updated" : "Application added");
            setModal(null);
          }}
          onDelete={(id) => {
            persistApps(state.apps.filter((a) => a.id !== id));
            show("Application removed");
            setModal(null);
          }}
        />
      )}
    </div>
  );
};
