import React, { useRef, useState } from "react";
import { AppItem, Category } from "../../types";
import { Modal } from "../common/Modal";
import { normalizeAppUrl, deriveAppNameFromUrl } from "../../utils/url";
import { createId } from "../../utils/id";

interface Props {
  categories: Category[];
  initial?: AppItem;
  defaultCategoryId?: string;
  onClose: () => void;
  onSave: (app: AppItem) => void;
  onDelete?: (id: string) => void;
}

export const AppFormModal: React.FC<Props> = ({
  categories,
  initial,
  defaultCategoryId,
  onClose,
  onSave,
  onDelete
}) => {
  const [name, setName] = useState(initial?.name ?? "");
  const [url, setUrl] = useState(initial?.url ?? "");
  const [categoryId, setCategoryId] = useState(
    initial?.categoryId ?? defaultCategoryId ?? categories[0]?.id ?? ""
  );
  const [iconType, setIconType] = useState<AppItem["iconType"]>(initial?.iconType ?? "favicon");
  const [iconValue, setIconValue] = useState<string | undefined>(initial?.iconValue);
  const [errors, setErrors] = useState<{ name?: string; url?: string }>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      setIconValue(reader.result as string);
      setIconType("custom");
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    const nextErrors: typeof errors = {};
    const normalized = normalizeAppUrl(url);
    if (!normalized) nextErrors.url = "Enter a valid URL, e.g. example.com or https://example.com.";

    if (Object.keys(nextErrors).length) {
      setErrors(nextErrors);
      return;
    }

    const finalName = deriveAppNameFromUrl(normalized!, name);

    onSave({
      id: initial?.id ?? createId(),
      name: finalName,
      url: normalized!,
      categoryId,
      iconType,
      iconValue,
      favorite: initial?.favorite ?? false,
      order: initial?.order ?? Date.now(),
      createdAt: initial?.createdAt ?? Date.now()
    });
  };

  return (
    <Modal title={initial ? "Edit application" : "Add application"} onClose={onClose}>
      <div className="field">
        <label htmlFor="app-url">URL</label>
        <input
          id="app-url"
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="e.g. github.com or speedtest.net"
          autoComplete="off"
        />
        {errors.url && <span className="field-error">{errors.url}</span>}
      </div>

      <div className="field">
        <label htmlFor="app-name">Application name (optional)</label>
        <input
          id="app-name"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Leave blank to auto-detect from website"
          autoComplete="off"
        />
        {errors.name && <span className="field-error">{errors.name}</span>}
      </div>

      <div className="field">
        <label htmlFor="app-category">Category</label>
        <select id="app-category" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      <div className="field">
        <label>Icon</label>
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <button
            type="button"
            className={`btn ${iconType === "favicon" ? "btn-primary" : ""}`}
            onClick={() => {
              setIconType("favicon");
              setIconValue(undefined);
            }}
            aria-pressed={iconType === "favicon"}
          >
            Website Logo
          </button>
          <button
            type="button"
            className={`btn ${iconType === "letter" ? "btn-primary" : ""}`}
            onClick={() => {
              setIconType("letter");
              setIconValue(undefined);
            }}
            aria-pressed={iconType === "letter"}
          >
            Monogram
          </button>
          <button type="button" className={`btn ${iconType === "custom" ? "btn-primary" : ""}`} onClick={() => fileInputRef.current?.click()}>
            Upload custom
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="visually-hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleFile(file);
            }}
          />
          {iconType === "custom" && iconValue && (
            <img src={iconValue} alt="Selected icon preview" width={28} height={28} style={{ borderRadius: 6 }} />
          )}
        </div>
      </div>

      <div className="btn-row">
        {initial && onDelete && (
          <button
            className="btn btn-danger"
            style={{ marginRight: "auto" }}
            onClick={() => onDelete(initial.id)}
          >
            Delete
          </button>
        )}
        <button className="btn" onClick={onClose}>
          Cancel
        </button>
        <button className="btn btn-primary" onClick={handleSave}>
          {initial ? "Save changes" : "Add application"}
        </button>
      </div>
    </Modal>
  );
};
