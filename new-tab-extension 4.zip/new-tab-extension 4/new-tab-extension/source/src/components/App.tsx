import React, { useEffect, useState } from "react";
import { useAppState } from "../store/AppStateContext";
import { BackgroundLayer } from "./background/BackgroundLayer";
import { useActiveWallpaper } from "../hooks/useActiveWallpaper";
import { useThemeApplication } from "../hooks/useThemeApplication";
import { GlobalSearch } from "./search/GlobalSearch";
import { CategoryBoard } from "./applications/CategoryBoard";
import { ProjectsPanel } from "./projects/ProjectsPanel";
import { Navigation, View } from "./common/Navigation";
import { SavedPanel } from "./saved/SavedPanel";
import { useSaved } from "../hooks/useSaved";
import { ShortcutsDialog } from "./shortcuts/ShortcutsDialog";
import { CardSizeControl } from "./layout/CardSizeControl";
import { ArrangeDialog } from "./layout/ArrangeDialog";
import { useShortcutHandlers } from "../services/shortcuts/shortcuts";
import { useApplyPrefs } from "../store/prefsStore";
import { kvGet, kvSet } from "../services/storage/kv";
import { SettingsPanel } from "./settings/SettingsPanel";
import { Onboarding } from "./onboarding/Onboarding";
import { generateDefaultWallpaper } from "../utils/generateDefaultWallpaper";
import { putBlob } from "../services/storage/blobStore";
import { createId } from "../utils/id";
import { registerToast } from "../utils/safeNavigate";
import { useToast } from "./common/Toast";
import { SavedItem } from "../types";

function todayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export const App: React.FC = () => {
  const { state, update, loaded } = useAppState();
  const { show } = useToast();
  const [view, setView] = useState<View>("home");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [addAppSignal, setAddAppSignal] = useState(0);
  const [addProjectSignal, setAddProjectSignal] = useState(0);
  const [focusProjectId, setFocusProjectId] = useState<string | null>(null);
  const [bootstrapping, setBootstrapping] = useState(false);

  const saved = useSaved();

  // One-time switch to the new look (light frosted cards, olive accent). Everything stays adjustable in Settings.
  useEffect(() => {
    if (!loaded) return;
    void (async () => {
      if (await kvGet<boolean>("newtab_design_v2")) return;
      await kvSet("newtab_design_v2", true);
      update((s) => ({
        ...s,
        settings: {
          ...s.settings,
          appearance: { ...s.settings.appearance, theme: "light", accent: "#6f7d3c", hoverTint: "#2f3a1c", glassIntensity: 62, glassBlur: 22 }
        }
      }));
    })();
  }, [loaded, update]);

  useApplyPrefs();
  const [showKeys, setShowKeys] = useState(false);
  const [showArrange, setShowArrange] = useState(false);
  useShortcutHandlers({
    "view.home": () => setView("home"),
    "view.saved": () => setView("saved"),
    "view.projects": () => setView("projects"),
    "app.add": () => { setView("home"); setAddAppSignal((n) => n + 1); },
    "settings.open": () => setSettingsOpen(true),
    "arrange.open": () => setShowArrange(true),
    "help.open": () => setShowKeys((v) => !v)
  });

  // Register toast fn for safeNavigate
  useEffect(() => {
    registerToast(show);
  }, [show]);

  useThemeApplication(state.settings.appearance);
  const resolvedWallpaper = useActiveWallpaper(state.wallpapers, state.settings.background);

  // First-run: paint and store a built-in default wallpaper
  useEffect(() => {
    if (!loaded || bootstrapping) return;
    if (state.wallpapers.length > 0) return;
    setBootstrapping(true);
    (async () => {
      const blob = await generateDefaultWallpaper(
        Math.min(window.screen.width * (window.devicePixelRatio || 1), 2560),
        Math.min(window.screen.height * (window.devicePixelRatio || 1), 1600)
      );
      const id = createId();
      const sourceKey = `wallpaper-${id}`;
      await putBlob(sourceKey, blob);
      update((s) => ({
        ...s,
        wallpapers: [
          {
            id,
            name: "Default",
            type: "image",
            sourceKey,
            favorite: false,
            isBuiltIn: true,
            createdAt: Date.now()
          }
        ],
        settings: {
          ...s.settings,
          background: { ...s.settings.background, activeWallpaperId: id }
        }
      }));
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded, state.wallpapers.length]);

  const handleAddSavedToHome = (item: SavedItem, categoryId: string) => {
    update((s) => ({
      ...s,
      apps: [
        ...s.apps,
        {
          id: createId(),
          name: item.title,
          url: item.url,
          categoryId,
          iconType: "letter",
          favorite: false,
          order: s.apps.filter((a) => a.categoryId === categoryId).length,
          createdAt: Date.now()
        }
      ]
    }));
    show("Added to Home", "success");
  };

  if (!loaded) {
    return <div className="skeleton-loading">Loading New Tab…</div>;
  }


  return (
    <div className="app-shell">
      <BackgroundLayer resolved={resolvedWallpaper} settings={state.settings.background} />

      <div className="app-content">
        {/* Top bar: Left (Nav), Center (Search), Right (Status pills) */}
        <div className="app-topbar">
          <div className="app-topbar-left">
            <Navigation
              view={view}
              onChangeView={setView}
              savedCount={saved.length}
              onPlus={() => (view === "home" ? setAddAppSignal((n) => n + 1) : setAddProjectSignal((n) => n + 1))}
            />
          </div>

          <div className="app-topbar-center">
            <GlobalSearch
              apps={state.apps}
              categories={state.categories}
              projects={state.projects}
              saved={saved}
              onOpenProject={(id) => {
                setFocusProjectId(id);
                setView("projects");
              }}
            />
          </div>

          <div className="app-topbar-right">
          </div>
        </div>

        {/* Main Content Area: 4-Column Board + 5th Column Sidebar */}
        <main className="app-main">
          {view === "saved" ? (
            <SavedPanel items={saved} categories={state.categories} onAddToHome={handleAddSavedToHome} />
          ) : view === "home" ? (
            <div className="board-layout">
              <div className="board-layout-main scrollable">
                <CategoryBoard openAddSignal={addAppSignal} />
              </div>
            </div>
          ) : (
            <ProjectsPanel
              openAddSignal={addProjectSignal}
              focusProjectId={focusProjectId}
              clearFocus={() => setFocusProjectId(null)}
            />
          )}
        </main>

        {/* Floating Action Buttons bottom-right */}
        <div className="floating-actions">
          <button className="fab-btn" onClick={() => setShowKeys(true)} title="Keyboard shortcuts ( ? )" aria-label="Keyboard shortcuts">
            ⌘
          </button>
          <CardSizeControl />
          <button className="fab-btn" onClick={() => setShowArrange(true)} title="Arrange cards ( Alt+A )" aria-label="Arrange cards">
            ⇅
          </button>
          <button
            className="fab-btn"
            onClick={() => setView((v) => (v === "home" ? "projects" : "home"))}
            title={view === "home" ? "View Projects" : "View Home"}
            aria-label="Toggle View"
          >
            ☰
          </button>
          <button
            className="fab-btn"
            onClick={() => setSettingsOpen(true)}
            title="Settings"
            aria-label="Settings"
          >
            ⚙
          </button>
        </div>
      </div>

      {showArrange && <ArrangeDialog onClose={() => setShowArrange(false)} />}
      {showKeys && <ShortcutsDialog onClose={() => setShowKeys(false)} />}
      {settingsOpen && <SettingsPanel onClose={() => setSettingsOpen(false)} />}
      {!state.settings.onboardingComplete && <Onboarding onDone={() => {}} />}
    </div>
  );
};
