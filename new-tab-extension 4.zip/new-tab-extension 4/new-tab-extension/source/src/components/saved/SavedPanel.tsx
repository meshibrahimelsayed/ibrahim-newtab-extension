import React, { useMemo, useState } from "react";
import { Category, SavedItem } from "../../types";
import { AppIcon } from "../applications/AppIcon";
import { hostnameOf } from "../../utils/url";
import { safeNavigate } from "../../utils/safeNavigate";
import { clearSaved, removeSaved, savedAsApp } from "../../services/saved/savedStore";
import "./saved.css";

interface Props {
  items: SavedItem[];
  categories: Category[];
  onAddToHome: (item: SavedItem, categoryId: string) => void;
}

const SavedRow = React.memo<{ item: SavedItem; categories: Category[]; onAddToHome: Props["onAddToHome"] }>(
  ({ item, categories, onAddToHome }) => (
    <li className="saved-row">
      <AppIcon app={savedAsApp(item)} size={24} />
      <button className="saved-open" onClick={() => safeNavigate(item.url)} title={item.url}>
        <span className="saved-title">{item.title}</span>
        <span className="saved-meta">
          {hostnameOf(item.url)} · {new Date(item.createdAt).toLocaleDateString()}
        </span>
      </button>
      <select
        className="saved-select"
        aria-label={`Add "${item.title}" to Home`}
        value=""
        onChange={(e) => e.target.value && onAddToHome(item, e.target.value)}
      >
        <option value="">Add to Home…</option>
        {categories.map((c) => (
          <option key={c.id} value={c.id}>{c.name}</option>
        ))}
      </select>
      <button className="saved-remove" onClick={() => void removeSaved(item.id)} aria-label="Remove" title="Remove">
        ✕
      </button>
    </li>
  )
);

export const SavedPanel: React.FC<Props> = ({ items, categories, onAddToHome }) => {
  const [q, setQ] = useState("");
  const shown = useMemo(() => {
    const s = q.trim().toLowerCase();
    return s ? items.filter((i) => i.title.toLowerCase().includes(s) || i.url.toLowerCase().includes(s)) : items;
  }, [items, q]);

  return (
    <section className="saved-panel scrollable" aria-label="Saved tabs">
      <div className="saved-head">
        <h2>Saved <span className="saved-count">{items.length}</span></h2>
        <input
          className="saved-filter"
          type="search"
          placeholder="Filter saved tabs"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Filter saved tabs"
        />
        {items.length > 0 && (
          <button
            className="saved-clear"
            onClick={() => confirm(`Remove all ${items.length} saved tabs?`) && void clearSaved()}
          >
            Clear all
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="saved-empty glass">
          <strong>Nothing saved yet</strong>
          <p>Press <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd> on any page, click the toolbar icon, or right-click a page or link and choose “Save to New Tab”.</p>
        </div>
      ) : shown.length === 0 ? (
        <div className="saved-empty glass"><strong>No matches</strong></div>
      ) : (
        <ul className="saved-list glass">
          {shown.map((i) => (
            <SavedRow key={i.id} item={i} categories={categories} onAddToHome={onAddToHome} />
          ))}
        </ul>
      )}
      <p className="saved-hint">Shortcuts: <kbd>Alt</kbd>+<kbd>1</kbd> Home · <kbd>Alt</kbd>+<kbd>2</kbd> Saved · <kbd>Alt</kbd>+<kbd>3</kbd> Projects · <kbd>/</kbd> Search. Change the save shortcut at chrome://extensions/shortcuts.</p>
    </section>
  );
};
