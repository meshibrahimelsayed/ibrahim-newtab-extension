import React, { useEffect, useRef, useState } from "react";
import { BackgroundSettings } from "../../types";
import { ResolvedWallpaper } from "../../hooks/useActiveWallpaper";
import { usePageVisible } from "../../hooks/usePageVisible";
import { useReducedMotion } from "../../hooks/useReducedMotion";
import "./background.css";

interface Layer {
  key: string;
  wallpaper: ResolvedWallpaper;
}

interface Props {
  resolved: ResolvedWallpaper | null;
  settings: BackgroundSettings;
}

/**
 * Renders the active wallpaper (image or video) full-bleed behind the
 * dashboard, crossfading between changes, pausing video when the tab is
 * hidden, and falling back to a plain gradient if media fails to load.
 */
export const BackgroundLayer: React.FC<Props> = ({ resolved, settings }) => {
  const [layers, setLayers] = useState<Layer[]>([]);
  const [failed, setFailed] = useState(false);
  const visible = usePageVisible();
  const reducedMotion = useReducedMotion();
  const videoRefs = useRef(new Map<string, HTMLVideoElement>());

  // Crossfade: keep the previous layer mounted briefly while the new one
  // fades in, then drop it.
  useEffect(() => {
    setFailed(false);
    if (!resolved) return;
    const key = `${resolved.wallpaper.id}-${resolved.sourceUrl}`;
    setLayers((prev) => {
      if (prev.length && prev[prev.length - 1].key === key) return prev;
      const next = [...prev, { key, wallpaper: resolved }];
      return next.slice(-2); // never keep more than old+new
    });
  }, [resolved]);

  useEffect(() => {
    if (layers.length < 2) return;
    const staleKey = layers[0].key;
    const timer = setTimeout(
      () => {
        setLayers((prev) => prev.filter((l) => l.key !== staleKey));
      },
      reducedMotion ? 0 : 900
    );
    return () => clearTimeout(timer);
  }, [layers, reducedMotion]);

  // Pause/resume video playback when the New Tab is hidden vs visible.
  useEffect(() => {
    for (const video of videoRefs.current.values()) {
      if (visible && settings.videoAutoplay) {
        video.play().catch(() => {
          /* autoplay can be blocked; poster remains visible */
        });
      } else {
        video.pause();
      }
    }
  }, [visible, settings.videoAutoplay, layers]);

  const filterStyle: React.CSSProperties = {
    filter: `brightness(${settings.brightness}%) contrast(${settings.contrast}%) saturate(${settings.saturation}%) blur(${settings.blur}px)`
  };

  return (
    <div className="bg-root" aria-hidden="true">
      {!failed &&
        layers.map((layer, idx) => {
          const isTop = idx === layers.length - 1;
          const wp = layer.wallpaper;
          return (
            <div
              key={layer.key}
              className={`bg-layer ${isTop ? "bg-layer-in" : "bg-layer-out"}`}
              style={filterStyle}
            >
              {wp.wallpaper.type === "video" ? (
                <video
                  ref={(el) => {
                    if (el) videoRefs.current.set(layer.key, el);
                    else videoRefs.current.delete(layer.key);
                  }}
                  className="bg-media"
                  src={wp.sourceUrl}
                  poster={wp.posterUrl}
                  muted
                  loop
                  playsInline
                  autoPlay={settings.videoAutoplay && visible}
                  onError={() => setFailed(true)}
                />
              ) : (
                <img
                  className="bg-media"
                  src={wp.sourceUrl}
                  alt=""
                  draggable={false}
                  onError={() => setFailed(true)}
                />
              )}
            </div>
          );
        })}
      {(failed || layers.length === 0) && <div className="bg-fallback" />}
      <div className="bg-overlay" style={{ opacity: settings.overlay / 100 }} />
      <div className="bg-vignette" style={{ opacity: settings.vignette / 100 }} />
    </div>
  );
};
