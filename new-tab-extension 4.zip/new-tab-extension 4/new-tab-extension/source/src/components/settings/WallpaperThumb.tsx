import React from "react";
import { Wallpaper } from "../../types";
import { useBlobUrl } from "../../hooks/useBlobUrl";

interface Props {
  wallpaper: Wallpaper;
  active: boolean;
  selectedForPlaylist?: boolean;
  onSelect: () => void;
  onContextMenu: (e: React.MouseEvent) => void;
}

export const WallpaperThumb: React.FC<Props> = ({ wallpaper, active, selectedForPlaylist, onSelect, onContextMenu }) => {
  const thumbKey = wallpaper.type === "video" ? wallpaper.posterKey ?? wallpaper.sourceKey : wallpaper.sourceKey;
  const url = useBlobUrl(thumbKey);

  return (
    <button
      className={`wallpaper-thumb ${active ? "wallpaper-thumb-active" : ""}`}
      onClick={onSelect}
      onContextMenu={onContextMenu}
      title={wallpaper.name}
    >
      {url ? <img src={url} alt="" /> : <div className="wallpaper-thumb-placeholder" />}
      {wallpaper.type === "video" && <span className="wallpaper-thumb-badge">▶</span>}
      {wallpaper.favorite && <span className="wallpaper-thumb-fav">★</span>}
      {selectedForPlaylist && <span className="wallpaper-thumb-check">✓</span>}
      <span className="wallpaper-thumb-name">{wallpaper.name}</span>
    </button>
  );
};
