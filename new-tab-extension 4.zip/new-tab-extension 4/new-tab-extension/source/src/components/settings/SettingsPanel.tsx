import React, { useRef, useState, useMemo } from "react";
import { useAppState } from "../../store/AppStateContext";
import { WallpaperLibrary } from "./WallpaperLibrary";
import { useToast } from "../common/Toast";
import { downloadExport, parseImportPayload } from "../../services/storage/importExport";
import { parseBookmarksHtml, parseRawUrls } from "../../services/bookmarks/bookmarkImporter";
import { createDefaultState } from "../../utils/defaults";
import "./settings.css";

type Tab = "appearance" | "bookmarks" | "background" | "layout" | "data";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "appearance", label: "Appearance", icon: "🎨" },
  { id: "bookmarks", label: "Import Bookmarks", icon: "🔖" },
  { id: "background", label: "Wallpapers", icon: "🖼️" },
  { id: "layout", label: "Layout", icon: "📐" },
  { id: "data", label: "Backup & Data", icon: "💾" }
];

const ACCENT_PRESETS = [
  { hex: "#3b82f6", label: "Electric Blue" },
  { hex: "#e8b968", label: "Warm Gold" },
  { hex: "#10b981", label: "Emerald Green" },
  { hex: "#8b5cf6", label: "Royal Violet" },
  { hex: "#f43f5e", label: "Crimson Rose" },
  { hex: "#06b6d4", label: "Cyan Teal" },
  { hex: "#f59e0b", label: "Sunset Amber" },
  { hex: "#ec4899", label: "Hot Pink" },
  { hex: "#6366f1", label: "Deep Indigo" },
  { hex: "#14b8a6", label: "Fresh Mint" },
  { hex: "#ffffff", label: "Pure White" },
  { hex: "#64748b", label: "Slate Gray" }
];

const HOVER_PRESETS = [
  { hex: "#ffffff", label: "White (default)" },
  { hex: "#3b82f6", label: "Blue" },
  { hex: "#e8b968", label: "Warm Gold" },
  { hex: "#5eb0be", label: "Cyan" },
  { hex: "#7abc8c", label: "Emerald" },
  { hex: "#000000", label: "Dark" }
];

function hexLuminance(hex: string): number {
  const n = parseInt(hex.replace("#", ""), 16);
  const r = ((n >> 16) & 255) / 255;
  const g = ((n >> 8) & 255) / 255;
  const b = (n & 255) / 255;
  const srgb = [r, g, b].map((c) => (c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)));
  return 0.2126 * srgb[0] + 0.7152 * srgb[1] + 0.0722 * srgb[2];
}

function contrastRatio(l1: number, l2: number): number {
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

export const SettingsPanel: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { state, update } = useAppState();
  const { show } = useToast();
  const [tab, setTab] = useState<Tab>("appearance");
  const [rawBookmarkText, setRawBookmarkText] = useState("");
  const [importMode, setImportMode] = useState<"merge" | "replace">("merge");
  const [bookmarkStats, setBookmarkStats] = useState<{ categoriesCount: number; appsCount: number } | null>(null);

  const importRef = useRef<HTMLInputElement>(null);
  const bookmarkFileRef = useRef<HTMLInputElement>(null);
  const s = state.settings;

  const patch = (section: keyof typeof s, value: any) =>
    update((prev) => ({ ...prev, settings: { ...prev.settings, [section]: { ...(prev.settings as any)[section], ...value } } }));

  const handleImportFile = async (file: File) => {
    const text = await file.text();
    const result = parseImportPayload(text);
    if (!result.ok || !result.state) {
      show(result.error ?? "Import failed — invalid configuration", "error");
      return;
    }
    update((prev) => ({ ...prev, ...result.state }));
    show("Import successful", "success");
  };

  const handleBookmarkFileUpload = async (file: File) => {
    try {
      const text = await file.text();
      const parsed = parseBookmarksHtml(text);
      if (parsed.totalImported === 0) {
        show("No valid bookmark links found in that file.", "error");
        return;
      }
      setBookmarkStats({ categoriesCount: parsed.categories.length, appsCount: parsed.apps.length });

      update((prev) => {
        if (importMode === "replace") {
          return {
            ...prev,
            categories: parsed.categories,
            apps: parsed.apps
          };
        } else {
          // Merge: append new categories and apps
          const existingCatNames = new Set(prev.categories.map((c) => c.name.toLowerCase()));
          const newCats = parsed.categories.filter((c) => !existingCatNames.has(c.name.toLowerCase()));
          const catMap = new Map<string, string>();
          
          // Map parsed categories to existing if duplicate name
          parsed.categories.forEach((c) => {
            const match = prev.categories.find((x) => x.name.toLowerCase() === c.name.toLowerCase());
            if (match) catMap.set(c.id, match.id);
            else catMap.set(c.id, c.id);
          });

          const remappedApps = parsed.apps.map((a) => ({
            ...a,
            categoryId: catMap.get(a.categoryId) || a.categoryId
          }));

          return {
            ...prev,
            categories: [...prev.categories, ...newCats],
            apps: [...prev.apps, ...remappedApps]
          };
        }
      });

      show(`Imported ${parsed.totalImported} bookmarks across ${parsed.categories.length} categories!`, "success");
    } catch {
      show("Failed to parse bookmark file.", "error");
    }
  };

  const handleRawUrlImport = () => {
    const parsed = parseRawUrls(rawBookmarkText);
    if (parsed.totalImported === 0) {
      show("Please enter at least one valid URL.", "error");
      return;
    }

    update((prev) => ({
      ...prev,
      categories: importMode === "replace" ? parsed.categories : [...prev.categories, ...parsed.categories],
      apps: importMode === "replace" ? parsed.apps : [...prev.apps, ...parsed.apps]
    }));

    setRawBookmarkText("");
    show(`Imported ${parsed.totalImported} links!`, "success");
  };

  const handleReset = () => {
    if (!window.confirm("Reset all settings, applications, and projects? Wallpapers you've added will remain.")) return;
    const fresh = createDefaultState();
    update((prev) => ({ ...fresh, wallpapers: prev.wallpapers }));
    show("Settings reset");
  };

  const accentContrastWarning = useMemo(() => {
    const accentL = hexLuminance(s.appearance.accent);
    const darkSurfaceL = 0.009;
    const lightSurfaceL = 1.0;
    const darkRatio = contrastRatio(accentL, darkSurfaceL);
    const lightRatio = contrastRatio(accentL, lightSurfaceL);
    if (darkRatio < 3.0 && lightRatio < 3.0) {
      return "This color may be hard to read against both dark and light backgrounds.";
    }
    if (s.appearance.theme === "dark" && darkRatio < 3.0) {
      return "This color may be hard to read against dark backgrounds.";
    }
    if (s.appearance.theme === "light" && lightRatio < 3.0) {
      return "This color may be hard to read against light backgrounds.";
    }
    return null;
  }, [s.appearance.accent, s.appearance.theme]);

  return (
    <div className="settings-overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="settings-panel glass">
        <div className="settings-sidebar">
          <h2 className="settings-heading">Settings</h2>
          <nav>
            {TABS.map((t) => (
              <button
                key={t.id}
                className={`settings-tab ${tab === t.id ? "settings-tab-active" : ""}`}
                onClick={() => setTab(t.id)}
              >
                <span className="settings-tab-icon">{t.icon}</span>
                <span>{t.label}</span>
              </button>
            ))}
          </nav>
          <button className="btn" onClick={onClose} style={{ marginTop: "auto" }}>
            Close
          </button>
        </div>

        <div className="settings-content scrollable">
          {tab === "appearance" && (
            <section>
              <div className="settings-group">
                <h3 className="settings-group-title">Theme</h3>
                <div className="settings-choice-row">
                  {(["dark", "light", "auto"] as const).map((mode) => (
                    <button
                      key={mode}
                      className={`wl-mode-btn ${s.appearance.theme === mode ? "wl-mode-btn-active" : ""}`}
                      onClick={() => patch("appearance", { theme: mode })}
                    >
                      <span className="wl-mode-label" style={{ textTransform: "capitalize" }}>
                        {mode === "auto" ? "🌓 System" : mode === "dark" ? "🌙 Dark" : "☀️ Light"}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="settings-group">
                <h3 className="settings-group-title">Accent Color</h3>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 10 }}>
                  {ACCENT_PRESETS.map((p) => (
                    <button
                      key={p.hex}
                      onClick={() => patch("appearance", { accent: p.hex })}
                      aria-label={`Accent ${p.label}`}
                      aria-pressed={s.appearance.accent === p.hex}
                      title={p.label}
                      style={{
                        width: 28,
                        height: 28,
                        borderRadius: "50%",
                        background: p.hex,
                        border: s.appearance.accent === p.hex ? "2px solid rgb(var(--text-primary))" : "2px solid transparent",
                        cursor: "pointer"
                      }}
                    />
                  ))}
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <label htmlFor="accent-picker" style={{ fontSize: 12, color: "rgb(var(--text-secondary))" }}>Custom:</label>
                  <input
                    id="accent-picker"
                    type="color"
                    value={s.appearance.accent}
                    onChange={(e) => patch("appearance", { accent: e.target.value })}
                    style={{ width: 36, height: 28, padding: 0, border: "none", cursor: "pointer", borderRadius: 6 }}
                  />
                </div>
                {accentContrastWarning && (
                  <span className="field-hint" style={{ color: "rgb(var(--warning))", display: "block", marginTop: 6 }}>
                    ⚠ {accentContrastWarning}
                  </span>
                )}
              </div>

              <div className="settings-group">
                <h3 className="settings-group-title">Hover Highlight Tint</h3>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 10 }}>
                  {HOVER_PRESETS.map((p) => (
                    <button
                      key={p.hex}
                      onClick={() => patch("appearance", { hoverTint: p.hex })}
                      aria-label={`Hover tint ${p.label}`}
                      aria-pressed={s.appearance.hoverTint === p.hex}
                      title={p.label}
                      style={{
                        width: 28,
                        height: 28,
                        borderRadius: "50%",
                        background: p.hex,
                        border: s.appearance.hoverTint === p.hex ? "2px solid rgb(var(--text-primary))" : "2px solid transparent",
                        cursor: "pointer"
                      }}
                    />
                  ))}
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <label htmlFor="hover-picker" style={{ fontSize: 12, color: "rgb(var(--text-secondary))" }}>Custom:</label>
                  <input
                    id="hover-picker"
                    type="color"
                    value={s.appearance.hoverTint || "#ffffff"}
                    onChange={(e) => patch("appearance", { hoverTint: e.target.value })}
                    style={{ width: 36, height: 28, padding: 0, border: "none", cursor: "pointer", borderRadius: 6 }}
                  />
                </div>
              </div>

              <div className="settings-group">
                <h3 className="settings-group-title">Glass Panel Effects</h3>
                <div className="wl-slider-row">
                  <label htmlFor="glass-blur-slider" style={{ fontSize: 12, minWidth: 60 }}>Blur</label>
                  <input
                    id="glass-blur-slider"
                    type="range"
                    min={0}
                    max={32}
                    value={s.appearance.glassBlur ?? 22}
                    onChange={(e) => patch("appearance", { glassBlur: Number(e.target.value) })}
                    style={{ flex: 1 }}
                  />
                  <span style={{ fontSize: 11, color: "rgb(var(--text-muted))", minWidth: 32 }}>{s.appearance.glassBlur ?? 22}px</span>
                </div>
                <div className="wl-slider-row" style={{ marginTop: 6 }}>
                  <label htmlFor="glass-alpha-slider" style={{ fontSize: 12, minWidth: 60 }}>Opacity</label>
                  <input
                    id="glass-alpha-slider"
                    type="range"
                    min={15}
                    max={90}
                    value={s.appearance.glassIntensity}
                    onChange={(e) => patch("appearance", { glassIntensity: Number(e.target.value) })}
                    style={{ flex: 1 }}
                  />
                  <span style={{ fontSize: 11, color: "rgb(var(--text-muted))", minWidth: 32 }}>{s.appearance.glassIntensity}%</span>
                </div>
              </div>

              <div className="settings-group">
                <h3 className="settings-group-title">Privacy</h3>
                <label className="wl-checkbox">
                  <input
                    type="checkbox"
                    checked={s.appearance.allowGoogleFavicons ?? false}
                    onChange={(e) => patch("appearance", { allowGoogleFavicons: e.target.checked })}
                  />
                  Allow fetching favicons from Google
                </label>
                <span className="field-hint" style={{ display: "block" }}>
                  When enabled, apps set to "Fetch favicon" will load icons from Google. Default: off.
                </span>
              </div>
            </section>
          )}

          {tab === "bookmarks" && (
            <section>
              <div className="settings-group">
                <h3 className="settings-group-title">Import Chrome / Browser Bookmarks</h3>
                <p className="field-hint" style={{ marginBottom: 14 }}>
                  Export your bookmarks HTML file from Chrome (press <code>Ctrl + Shift + O</code> or <code>⌘ + Option + B</code> in Chrome → click <b>⋮</b> → <b>Export bookmarks</b>) and upload it here. Folders will automatically become Categories!
                </p>

                <div className="bookmark-import-zone" onClick={() => bookmarkFileRef.current?.click()}>
                  <span style={{ fontSize: 32 }}>📂</span>
                  <span style={{ fontWeight: 600, fontSize: 14 }}>Click or drag your <code>bookmarks.html</code> file here</span>
                  <span style={{ fontSize: 12, color: "rgb(var(--text-muted))" }}>Supports Chrome, Edge, Firefox, and Safari bookmark exports</span>
                </div>
                <input
                  ref={bookmarkFileRef}
                  type="file"
                  accept=".html,text/html"
                  className="visually-hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleBookmarkFileUpload(file);
                  }}
                />

                <div style={{ display: "flex", gap: 16, marginTop: 14, alignItems: "center" }}>
                  <label style={{ fontSize: 12, fontWeight: 600 }}>Import mode:</label>
                  <label className="wl-radio">
                    <input
                      type="radio"
                      name="importMode"
                      checked={importMode === "merge"}
                      onChange={() => setImportMode("merge")}
                    />
                    Merge with existing apps
                  </label>
                  <label className="wl-radio">
                    <input
                      type="radio"
                      name="importMode"
                      checked={importMode === "replace"}
                      onChange={() => setImportMode("replace")}
                    />
                    Replace all current apps
                  </label>
                </div>
              </div>

              <div className="settings-group">
                <h3 className="settings-group-title">Or Paste Links in Bulk</h3>
                <p className="field-hint" style={{ marginBottom: 8 }}>
                  Paste a list of URLs (one per line). They will be added to your board instantly.
                </p>
                <textarea
                  rows={4}
                  value={rawBookmarkText}
                  onChange={(e) => setRawBookmarkText(e.target.value)}
                  placeholder="https://github.com&#10;https://youtube.com&#10;https://news.ycombinator.com"
                  style={{
                    width: "100%",
                    background: "rgb(var(--surface) / 0.7)",
                    border: "1px solid rgb(var(--border-rgb) / 0.15)",
                    borderRadius: 8,
                    padding: 10,
                    fontSize: 12.5,
                    color: "rgb(var(--text-primary))",
                    fontFamily: "var(--font-mono)"
                  }}
                />
                <button
                  className="btn btn-primary"
                  onClick={handleRawUrlImport}
                  disabled={!rawBookmarkText.trim()}
                  style={{ marginTop: 8 }}
                >
                  Import Pasted Links
                </button>
              </div>
            </section>
          )}

          {tab === "background" && <WallpaperLibrary />}

          {tab === "layout" && (
            <section>
              <div className="settings-group">
                <h3 className="settings-group-title">Visibility</h3>
                {(
                  [
                    ["projects", "Projects workspace tab"]
                  ] as const
                ).map(([key, label]) => (
                  <label className="wl-checkbox" key={key} style={{ marginBottom: 8 }}>
                    <input
                      type="checkbox"
                      checked={s.layout.widgets[key]}
                      onChange={(e) => patch("layout", { widgets: { ...s.layout.widgets, [key]: e.target.checked } })}
                    />
                    {label}
                  </label>
                ))}
              </div>

              <div className="settings-group">
                <h3 className="settings-group-title">Grid Density</h3>
                <div className="settings-choice-row">
                  {(["comfortable", "compact"] as const).map((d) => (
                    <button
                      key={d}
                      className={`wl-mode-btn ${s.layout.gridDensity === d ? "wl-mode-btn-active" : ""}`}
                      onClick={() => patch("layout", { gridDensity: d })}
                    >
                      <span className="wl-mode-label" style={{ textTransform: "capitalize" }}>
                        {d}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </section>
          )}

                                        {tab === "data" && (
            <section>
              <div className="settings-group">
                <h3 className="settings-group-title">Export Backup</h3>
                <p className="field-hint" style={{ marginBottom: 10 }}>
                  Download your applications, categories, projects, tasks, and settings as a JSON file.
                </p>
                <button className="btn" onClick={() => downloadExport(state)}>
                  Download Backup File (.json)
                </button>
              </div>

              <div className="settings-group">
                <h3 className="settings-group-title">Restore Backup</h3>
                <p className="field-hint" style={{ marginBottom: 10 }}>
                  Restore from a previously exported file.
                </p>
                <button className="btn" onClick={() => importRef.current?.click()}>
                  Upload Backup (.json)
                </button>
                <input
                  ref={importRef}
                  type="file"
                  accept="application/json"
                  className="visually-hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleImportFile(file);
                  }}
                />
              </div>

              <div className="settings-group">
                <h3 className="settings-group-title" style={{ color: "rgb(var(--danger))" }}>Reset to Defaults</h3>
                <p className="field-hint" style={{ marginBottom: 10 }}>
                  Restore default categories, applications, and layout.
                </p>
                <button className="btn btn-danger" onClick={handleReset}>
                  Reset All Dashboard Data
                </button>
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
};
