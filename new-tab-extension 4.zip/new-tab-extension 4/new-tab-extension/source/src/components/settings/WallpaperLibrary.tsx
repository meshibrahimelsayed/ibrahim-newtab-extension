import React, { useRef, useState } from "react";
import { useAppState } from "../../store/AppStateContext";
import { WallpaperThumb } from "./WallpaperThumb";
import { ContextMenu, ContextMenuItem } from "../common/ContextMenu";
import { addWallpaperFromFile, removeWallpaperAssets } from "../../services/wallpapers/wallpaperLibrary";
import { useToast } from "../common/Toast";
import { WallpaperMode } from "../../types";
import "./wallpaper-library.css";

const MODES: { value: WallpaperMode; label: string; hint: string }[] = [
  { value: "fixed", label: "Fixed", hint: "Always use the selected wallpaper" },
  { value: "random", label: "Random", hint: "A random wallpaper each time you open a tab" },
  { value: "daily", label: "Daily", hint: "A new wallpaper once a day" },
  { value: "playlist", label: "Playlist", hint: "Cycle through a chosen collection" },
  { value: "favorites", label: "Favorites only", hint: "Randomize only your favorites" }
];

export const WallpaperLibrary: React.FC = () => {
  const { state, update } = useAppState();
  const { show } = useToast();
  const [menu, setMenu] = useState<{ x: number; y: number; id: string } | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const bg = state.settings.background;

  const handleFiles = async (files: FileList) => {
    setUploading(true);
    for (const file of Array.from(files)) {
      try {
        const { wallpaper } = await addWallpaperFromFile(file);
        update((s) => ({
          ...s,
          wallpapers: [...s.wallpapers, wallpaper],
          settings: {
            ...s.settings,
            background:
              s.settings.background.activeWallpaperId === null
                ? { ...s.settings.background, activeWallpaperId: wallpaper.id }
                : s.settings.background
          }
        }));
        show(`Added "${wallpaper.name}"`, "success");
      } catch (err) {
        show(err instanceof Error ? err.message : "Couldn't add that file", "error");
      }
    }
    setUploading(false);
  };

  const menuItems: ContextMenuItem[] = menu
    ? (() => {
        const wp = state.wallpapers.find((w) => w.id === menu.id);
        if (!wp) return [];
        return [
          {
            label: "Set as active",
            onSelect: () =>
              update((s) => ({
                ...s,
                settings: { ...s.settings, background: { ...s.settings.background, mode: "fixed", activeWallpaperId: wp.id } }
              }))
          },
          {
            label: wp.favorite ? "Remove from favorites" : "Add to favorites",
            onSelect: () =>
              update((s) => ({
                ...s,
                wallpapers: s.wallpapers.map((w) => (w.id === wp.id ? { ...w, favorite: !w.favorite } : w))
              }))
          },
          {
            label: "Rename",
            onSelect: () => {
              const name = window.prompt("Rename wallpaper", wp.name);
              if (name && name.trim()) {
                update((s) => ({
                  ...s,
                  wallpapers: s.wallpapers.map((w) => (w.id === wp.id ? { ...w, name: name.trim() } : w))
                }));
              }
            }
          },
          {
            label: "Delete",
            danger: true,
            onSelect: async () => {
              if (!window.confirm(`Delete "${wp.name}"? This can't be undone.`)) return;
              await removeWallpaperAssets(wp);
              update((s) => ({
                ...s,
                wallpapers: s.wallpapers.filter((w) => w.id !== wp.id),
                settings: {
                  ...s.settings,
                  background: {
                    ...s.settings.background,
                    activeWallpaperId: s.settings.background.activeWallpaperId === wp.id ? null : s.settings.background.activeWallpaperId,
                    playlistIds: s.settings.background.playlistIds.filter((id) => id !== wp.id)
                  }
                }
              }));
              show("Wallpaper deleted");
            }
          }
        ];
      })()
    : [];

  const updateBg = (patch: Partial<typeof bg>) =>
    update((s) => ({ ...s, settings: { ...s.settings, background: { ...s.settings.background, ...patch } } }));

  return (
    <div className="wallpaper-library">
      <div className="wl-header">
        <h3 className="wl-title">My wallpapers</h3>
        <button className="btn btn-primary" onClick={() => fileRef.current?.click()} disabled={uploading}>
          {uploading ? "Adding…" : "+ Add wallpaper"}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*,video/*"
          multiple
          className="visually-hidden"
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
        />
      </div>

      <div className="wl-grid">
        {state.wallpapers.map((w) => (
          <WallpaperThumb
            key={w.id}
            wallpaper={w}
            active={bg.activeWallpaperId === w.id}
            selectedForPlaylist={bg.mode === "playlist" && bg.playlistIds.includes(w.id)}
            onSelect={() => {
              if (bg.mode === "playlist") {
                const set = new Set(bg.playlistIds);
                if (set.has(w.id)) set.delete(w.id);
                else set.add(w.id);
                updateBg({ playlistIds: Array.from(set) });
              } else {
                updateBg({ mode: "fixed", activeWallpaperId: w.id });
              }
            }}
            onContextMenu={(e) => {
              e.preventDefault();
              setMenu({ x: e.clientX, y: e.clientY, id: w.id });
            }}
          />
        ))}
      </div>

      <div className="wl-modes">
        <h3 className="wl-title">Wallpaper mode</h3>
        <div className="wl-mode-list">
          {MODES.map((m) => (
            <button
              key={m.value}
              className={`wl-mode-btn ${bg.mode === m.value ? "wl-mode-btn-active" : ""}`}
              onClick={() => updateBg({ mode: m.value })}
            >
              <span className="wl-mode-label">{m.label}</span>
              <span className="wl-mode-hint">{m.hint}</span>
            </button>
          ))}
        </div>
        {bg.mode === "playlist" && (
          <p className="field-hint">Click wallpapers above to add or remove them from the playlist ({bg.playlistIds.length} selected).</p>
        )}
      </div>

      <div className="wl-sliders">
        <h3 className="wl-title">Background treatment</h3>
        {(
          [
            ["brightness", "Brightness", 40, 160],
            ["contrast", "Contrast", 40, 160],
            ["saturation", "Saturation", 0, 200],
            ["blur", "Blur", 0, 20],
            ["vignette", "Vignette", 0, 100],
            ["overlay", "Overlay", 0, 100]
          ] as const
        ).map(([key, label, min, max]) => (
          <div key={key} className="wl-slider-row">
            <label htmlFor={`slider-${key}`}>{label}</label>
            <input
              id={`slider-${key}`}
              type="range"
              min={min}
              max={max}
              value={bg[key]}
              onChange={(e) => updateBg({ [key]: Number(e.target.value) } as Partial<typeof bg>)}
            />
          </div>
        ))}
        <label className="wl-checkbox">
          <input
            type="checkbox"
            checked={bg.videoAutoplay}
            onChange={(e) => updateBg({ videoAutoplay: e.target.checked })}
          />
          Autoplay video wallpapers
        </label>
      </div>

      {menu && <ContextMenu x={menu.x} y={menu.y} items={menuItems} onClose={() => setMenu(null)} />}
    </div>
  );
};
