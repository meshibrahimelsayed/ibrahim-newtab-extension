import { useEffect, useMemo, useRef, useState } from "react";
import { BackgroundSettings, Wallpaper } from "../types";
import { resolveActiveWallpaper } from "../services/wallpapers/wallpaperEngine";
import { getBlobObjectUrl } from "../services/storage/blobStore";

export interface ResolvedWallpaper {
  wallpaper: Wallpaper;
  sourceUrl: string;
  posterUrl?: string;
}

export function useActiveWallpaper(
  wallpapers: Wallpaper[],
  bg: BackgroundSettings
): ResolvedWallpaper | null {
  // Random mode should stay put for the session instead of re-rolling on
  // every unrelated state update — only re-roll when the wallpaper pool or
  // mode actually changes.
  const randomPick = useRef<Wallpaper | null>(null);
  const lastKey = useRef<string>("");

  const wallpaper = useMemo(() => {
    const key = `${bg.mode}:${bg.activeWallpaperId}:${wallpapers.map((w) => w.id).join(",")}`;
    if (bg.mode === "random") {
      if (key !== lastKey.current || !randomPick.current) {
        randomPick.current = resolveActiveWallpaper(wallpapers, bg);
        lastKey.current = key;
      }
      return randomPick.current;
    }
    lastKey.current = key;
    return resolveActiveWallpaper(wallpapers, bg);
  }, [wallpapers, bg]);

  const [resolved, setResolved] = useState<ResolvedWallpaper | null>(null);

  useEffect(() => {
    let cancelled = false;
    if (!wallpaper) {
      setResolved(null);
      return;
    }
    (async () => {
      const sourceUrl = await getBlobObjectUrl(wallpaper.sourceKey);
      const posterUrl = wallpaper.posterKey ? await getBlobObjectUrl(wallpaper.posterKey) : undefined;
      if (!cancelled && sourceUrl) {
        setResolved({ wallpaper, sourceUrl, posterUrl });
      } else if (!cancelled) {
        setResolved(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [wallpaper]);

  return resolved;
}
