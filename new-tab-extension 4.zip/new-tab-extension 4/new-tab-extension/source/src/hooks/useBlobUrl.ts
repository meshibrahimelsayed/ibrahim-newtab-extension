import { useEffect, useState } from "react";
import { getBlobObjectUrl } from "../services/storage/blobStore";

export function useBlobUrl(key: string | undefined): string | undefined {
  const [url, setUrl] = useState<string | undefined>(undefined);

  useEffect(() => {
    let cancelled = false;
    if (!key) {
      setUrl(undefined);
      return;
    }
    getBlobObjectUrl(key).then((u) => {
      if (!cancelled) setUrl(u);
    });
    return () => {
      cancelled = true;
    };
  }, [key]);

  return url;
}
