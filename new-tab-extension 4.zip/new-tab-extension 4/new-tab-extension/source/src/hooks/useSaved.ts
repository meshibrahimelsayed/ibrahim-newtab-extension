import { useEffect, useState } from "react";
import { SavedItem } from "../types";
import { loadSaved, subscribeSaved } from "../services/saved/savedStore";

export function useSaved(): SavedItem[] {
  const [items, setItems] = useState<SavedItem[]>([]);
  useEffect(() => {
    let alive = true;
    const sync = () => void loadSaved().then((l) => alive && setItems(l));
    sync();
    const off = subscribeSaved(sync);
    return () => { alive = false; off(); };
  }, []);
  return items;
}
