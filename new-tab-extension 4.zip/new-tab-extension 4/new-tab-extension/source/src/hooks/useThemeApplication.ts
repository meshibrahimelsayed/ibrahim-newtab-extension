import { useEffect } from "react";
import { AppearanceSettings } from "../types";

function hexToRgbTriplet(hex: string): string {
  const n = parseInt(hex.replace("#", ""), 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}

/**
 * Convert a hex color to an rgba CSS string at a given alpha.
 */
function hexToRgba(hex: string, alpha: number): string {
  const n = parseInt(hex.replace("#", ""), 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function useThemeApplication(appearance: AppearanceSettings): void {
  useEffect(() => {
    const root = document.documentElement;

    const applyResolvedTheme = () => {
      const resolved =
        appearance.theme === "auto"
          ? window.matchMedia("(prefers-color-scheme: light)").matches
            ? "light"
            : "dark"
          : appearance.theme;
      root.setAttribute("data-theme", resolved);
    };

    applyResolvedTheme();

    let mq: MediaQueryList | undefined;
    if (appearance.theme === "auto") {
      mq = window.matchMedia("(prefers-color-scheme: light)");
      mq.addEventListener("change", applyResolvedTheme);
    }
    return () => mq?.removeEventListener("change", applyResolvedTheme);
  }, [appearance.theme]);

  useEffect(() => {
    document.documentElement.style.setProperty("--accent", hexToRgbTriplet(appearance.accent));
    document.documentElement.style.setProperty("--accent-hex", appearance.accent);
  }, [appearance.accent]);

  useEffect(() => {
    document.documentElement.style.setProperty("--glass-alpha", String(appearance.glassIntensity / 100));
  }, [appearance.glassIntensity]);

  // Apply hover tint as an rgba color (0.08 base alpha)
  useEffect(() => {
    const tint = appearance.hoverTint || "#ffffff";
    document.documentElement.style.setProperty("--hover-tint", hexToRgba(tint, 0.08));
  }, [appearance.hoverTint]);

  // Apply glass blur
  useEffect(() => {
    const blur = appearance.glassBlur ?? 20;
    document.documentElement.style.setProperty("--glass-blur", `${blur}px`);
  }, [appearance.glassBlur]);
}
