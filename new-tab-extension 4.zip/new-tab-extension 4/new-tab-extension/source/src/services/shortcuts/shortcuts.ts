import { useEffect, useRef, useSyncExternalStore } from "react";
import { kvGet, kvSet } from "../storage/kv";

export interface ShortcutAction { id: string; label: string; hint: string; combo: string }

/** In-page shortcuts you can rebind. Combos use KeyboardEvent.code, e.g. "Alt+KeyN". */
export const ACTIONS: ShortcutAction[] = [
  { id: "view.home", label: "Go to Home", hint: "Your bookmark categories", combo: "Alt+Digit1" },
  { id: "view.saved", label: "Go to Saved", hint: "Tabs you saved with Quick Save", combo: "Alt+Digit2" },
  { id: "view.projects", label: "Go to Projects", hint: "Project notes and links", combo: "Alt+Digit3" },
  { id: "app.add", label: "Add a bookmark", hint: "Opens the add form on Home", combo: "Alt+KeyN" },
  { id: "settings.open", label: "Open settings", hint: "Appearance, wallpapers, widgets, backup", combo: "Alt+Comma" },
  { id: "arrange.open", label: "Arrange cards", hint: "Reorder or sort your bookmark cards precisely", combo: "Alt+KeyA" },
  { id: "help.open", label: "Show / hide shortcuts", hint: "This window", combo: "Shift+Slash" }
];

const KEY = "newtab_shortcuts_v1";
const defaults = Object.fromEntries(ACTIONS.map((a) => [a.id, a.combo])) as Record<string, string>;
let overrides: Record<string, string> = {};
let bindings = { ...defaults };
const subs = new Set<() => void>();
const apply = () => {
  bindings = { ...defaults, ...overrides };
  subs.forEach((f) => f());
};
void kvGet<Record<string, string>>(KEY).then((v) => {
  overrides = v ?? {};
  apply();
});

export const useBindings = () =>
  useSyncExternalStore((cb) => (subs.add(cb), () => subs.delete(cb)), () => bindings);

const MODIFIER_CODES = /^(Control|Shift|Alt|Meta)(Left|Right)$/;
export function comboFromEvent(e: KeyboardEvent): string | null {
  if (MODIFIER_CODES.test(e.code)) return null;
  return [e.ctrlKey && "Ctrl", e.altKey && "Alt", e.shiftKey && "Shift", e.metaKey && "Meta", e.code].filter(Boolean).join("+");
}

export function prettyCombo(combo: string): string[] {
  const map: Record<string, string> = { Slash: "/", Comma: ",", Period: ".", ArrowLeft: "←", ArrowRight: "→", ArrowUp: "↑", ArrowDown: "↓" };
  return combo.split("+").map((p) => map[p] ?? p.replace(/^(Key|Digit)/, ""));
}

/** Returns an error message if the combo can't be used. */
export function setBinding(id: string, combo: string): string | null {
  const clash = ACTIONS.find((a) => a.id !== id && bindings[a.id] === combo);
  if (clash) return `Already used by “${clash.label}”.`;
  overrides = { ...overrides, [id]: combo };
  apply();
  void kvSet(KEY, overrides);
  return null;
}
export function resetBindings() {
  overrides = {};
  apply();
  void kvSet(KEY, overrides);
}

export function useShortcutHandlers(handlers: Record<string, () => void>) {
  const ref = useRef(handlers);
  ref.current = handlers;
  const b = useBindings();
  useEffect(() => {
    const byCombo = new Map(Object.entries(b).map(([id, c]) => [c, id]));
    const onKey = (e: KeyboardEvent) => {
      if (e.isComposing) return;
      const combo = comboFromEvent(e);
      const id = combo && byCombo.get(combo);
      if (!id) return;
      const el = e.target as HTMLElement;
      const typing = el.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(el.tagName);
      if (typing && !/Ctrl|Alt|Meta/.test(combo)) return;
      const fn = ref.current[id];
      if (fn) {
        e.preventDefault();
        fn();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [b]);
}
