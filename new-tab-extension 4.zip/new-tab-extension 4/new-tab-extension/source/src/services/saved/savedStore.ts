import { AppItem, SavedItem } from "../../types";
import { kvGet, kvSet, kvSubscribe } from "../storage/kv";

export const SAVED_KEY = "newtab_saved_v1";

// Serialise read-modify-write operations so rapid clicks can't overwrite each other.
let queue: Promise<unknown> = Promise.resolve();

export const loadSaved = async (): Promise<SavedItem[]> => (await kvGet<SavedItem[]>(SAVED_KEY)) ?? [];

function mutate(fn: (list: SavedItem[]) => SavedItem[]): Promise<void> {
  const run = queue.then(async () => kvSet(SAVED_KEY, fn(await loadSaved())));
  queue = run.catch(() => undefined);
  return run;
}

export const removeSaved = (id: string) => mutate((l) => l.filter((i) => i.id !== id));
export const clearSaved = () => mutate(() => []);
export const subscribeSaved = (cb: () => void) => kvSubscribe(SAVED_KEY, cb);

/** Lets saved items reuse AppIcon (favicon with monogram fallback). */
export const savedAsApp = (i: SavedItem): AppItem => ({
  id: i.id, name: i.title, url: i.url, categoryId: "", iconType: "letter",
  favorite: false, order: 0, createdAt: i.createdAt
});
