/** True when running inside an actual Chrome extension context. */
export const isExtensionEnv =
  typeof chrome !== "undefined" && !!chrome.storage && !!chrome.storage.local;

export const prefersReducedMotion = (): boolean =>
  typeof window !== "undefined" &&
  window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true;
