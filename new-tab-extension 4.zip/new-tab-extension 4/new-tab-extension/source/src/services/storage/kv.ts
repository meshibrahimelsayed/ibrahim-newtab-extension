import { isExtensionEnv } from "../chrome/env";

/**
 * Thin key-value layer. Inside the real extension this is backed by
 * chrome.storage.local (persistent, survives browser restarts, synced across
 * every open New Tab instance via onChanged). Outside the extension (e.g.
 * `npm run dev` in a normal browser tab, for local iteration) it falls back
 * to localStorage so the app is still usable.
 */
export async function kvGet<T>(key: string): Promise<T | undefined> {
  if (isExtensionEnv) {
    const result = await chrome.storage.local.get(key);
    return result[key] as T | undefined;
  }
  const raw = localStorage.getItem(key);
  return raw ? (JSON.parse(raw) as T) : undefined;
}

export async function kvSet<T>(key: string, value: T): Promise<void> {
  if (isExtensionEnv) {
    await chrome.storage.local.set({ [key]: value });
    return;
  }
  localStorage.setItem(key, JSON.stringify(value));
  // Mimic chrome.storage.onChanged for same-tab dev testing.
  window.dispatchEvent(new CustomEvent("kv-changed", { detail: { key } }));
}

export function kvSubscribe(key: string, onChange: () => void): () => void {
  if (isExtensionEnv) {
    const listener = (changes: { [k: string]: chrome.storage.StorageChange }, area: string) => {
      if (area === "local" && key in changes) onChange();
    };
    chrome.storage.onChanged.addListener(listener);
    return () => chrome.storage.onChanged.removeListener(listener);
  }
  const listener = (e: Event) => {
    const detail = (e as CustomEvent).detail;
    if (detail?.key === key) onChange();
  };
  window.addEventListener("kv-changed", listener);
  return () => window.removeEventListener("kv-changed", listener);
}
