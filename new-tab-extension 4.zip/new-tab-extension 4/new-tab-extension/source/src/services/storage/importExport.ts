import { AppState, ExportPayload } from "../../types";
import { SCHEMA_VERSION } from "../../utils/defaults";

export function buildExportPayload(state: AppState): ExportPayload {
  return {
    schema: "ibrahim-newtab",
    schemaVersion: SCHEMA_VERSION,
    exportedAt: Date.now(),
    data: {
      version: state.version,
      categories: state.categories,
      apps: state.apps,
      projects: state.projects,
      settings: state.settings,
      tasks: state.tasks,
      // Binary wallpaper data can't be exported into JSON — only metadata is
      // preserved, so wallpaper mode/settings survive but the media itself
      // does not travel with the file.
      wallpapers: state.wallpapers.map(({ sourceKey, posterKey, ...rest }) => rest)
    }
  };
}

export function downloadExport(state: AppState): void {
  const payload = buildExportPayload(state);
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `newtab-settings-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export interface ImportOutcome {
  ok: boolean;
  error?: string;
  state?: Partial<AppState>;
}

/** Validates the shape of an imported file before it ever touches app state.
 *  Accepts both "ibrahim-newtab" and legacy "aurora-newtab" schemas. */
export function parseImportPayload(raw: string): ImportOutcome {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return { ok: false, error: "That file isn't valid JSON." };
  }

  if (
    typeof parsed !== "object" ||
    parsed === null ||
    ((parsed as any).schema !== "ibrahim-newtab" && (parsed as any).schema !== "aurora-newtab") ||
    typeof (parsed as any).data !== "object"
  ) {
    return { ok: false, error: "This file doesn't look like a New Tab settings export." };
  }

  const data = (parsed as ExportPayload).data;
  if (!Array.isArray(data.categories) || !Array.isArray(data.apps) || !Array.isArray(data.projects) || !data.settings) {
    return { ok: false, error: "The file is missing required sections." };
  }

  return {
    ok: true,
    state: {
      categories: data.categories,
      apps: data.apps,
      projects: data.projects,
      settings: data.settings,
      tasks: (data as any).tasks ?? []
      // wallpapers intentionally omitted — no binary data to restore, and we
      // don't want to leave the active wallpaper pointing at nothing.
    }
  };
}
