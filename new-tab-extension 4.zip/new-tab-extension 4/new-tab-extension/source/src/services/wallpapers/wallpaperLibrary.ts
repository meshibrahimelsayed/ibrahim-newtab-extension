import { Wallpaper, WallpaperType } from "../../types";
import { createId } from "../../utils/id";
import { putBlob, deleteBlob } from "../storage/blobStore";

const MAX_IMAGE_BYTES = 25 * 1024 * 1024; // 25MB
const MAX_VIDEO_BYTES = 200 * 1024 * 1024; // 200MB

export interface AddWallpaperResult {
  wallpaper: Wallpaper;
}

export async function addWallpaperFromFile(file: File): Promise<AddWallpaperResult> {
  const isVideo = file.type.startsWith("video/");
  const isImage = file.type.startsWith("image/");
  if (!isVideo && !isImage) {
    throw new Error("Unsupported file type. Choose an image or video.");
  }
  const limit = isVideo ? MAX_VIDEO_BYTES : MAX_IMAGE_BYTES;
  if (file.size > limit) {
    throw new Error(`File is too large (max ${Math.round(limit / (1024 * 1024))}MB).`);
  }

  const type: WallpaperType = isVideo ? "video" : "image";
  const id = createId();
  const sourceKey = `wallpaper-${id}`;
  await putBlob(sourceKey, file);

  let posterKey: string | undefined;
  if (isVideo) {
    try {
      posterKey = `wallpaper-${id}-poster`;
      const posterBlob = await extractVideoFrame(file);
      if (posterBlob) await putBlob(posterKey, posterBlob);
      else posterKey = undefined;
    } catch {
      posterKey = undefined;
    }
  }

  const wallpaper: Wallpaper = {
    id,
    name: file.name.replace(/\.[^/.]+$/, ""),
    type,
    sourceKey,
    posterKey,
    favorite: false,
    isBuiltIn: false,
    createdAt: Date.now()
  };

  return { wallpaper };
}

function extractVideoFrame(file: File): Promise<Blob | null> {
  return new Promise((resolve) => {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.src = URL.createObjectURL(file);

    const cleanup = () => URL.revokeObjectURL(video.src);

    video.onloadeddata = () => {
      video.currentTime = Math.min(0.5, (video.duration || 1) / 4);
    };
    video.onseeked = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          cleanup();
          resolve(null);
          return;
        }
        ctx.drawImage(video, 0, 0);
        canvas.toBlob((blob) => {
          cleanup();
          resolve(blob);
        }, "image/jpeg", 0.85);
      } catch {
        cleanup();
        resolve(null);
      }
    };
    video.onerror = () => {
      cleanup();
      resolve(null);
    };
  });
}

export async function removeWallpaperAssets(wallpaper: Wallpaper): Promise<void> {
  await deleteBlob(wallpaper.sourceKey);
  if (wallpaper.posterKey) await deleteBlob(wallpaper.posterKey);
}
