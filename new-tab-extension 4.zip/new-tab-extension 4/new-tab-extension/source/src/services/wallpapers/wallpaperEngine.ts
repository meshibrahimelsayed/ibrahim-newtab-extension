import { BackgroundSettings, Wallpaper } from "../../types";

function dailyIndexSeed(): number {
  const start = new Date();
  const dayNumber = Math.floor(
    Date.UTC(start.getFullYear(), start.getMonth(), start.getDate()) / 86_400_000
  );
  return dayNumber;
}

/**
 * Resolves which wallpaper should currently be shown given the mode and the
 * wallpaper library. Pure function — no side effects — so it's trivial to
 * reason about and test.
 */
export function resolveActiveWallpaper(
  wallpapers: Wallpaper[],
  bg: BackgroundSettings
): Wallpaper | null {
  if (wallpapers.length === 0) return null;

  switch (bg.mode) {
    case "fixed": {
      return wallpapers.find((w) => w.id === bg.activeWallpaperId) ?? wallpapers[0];
    }
    case "favorites": {
      const favs = wallpapers.filter((w) => w.favorite);
      const pool = favs.length ? favs : wallpapers;
      return pool[dailyIndexSeed() % pool.length];
    }
    case "daily": {
      return wallpapers[dailyIndexSeed() % wallpapers.length];
    }
    case "playlist": {
      const pool = bg.playlistIds.length
        ? wallpapers.filter((w) => bg.playlistIds.includes(w.id))
        : wallpapers;
      if (pool.length === 0) return wallpapers[0];
      return pool[dailyIndexSeed() % pool.length];
    }
    case "random": {
      // Stable within a session (recomputed on reload) rather than flickering
      // between different wallpapers on every re-render.
      const idx = Math.floor(Math.random() * wallpapers.length);
      return wallpapers[idx];
    }
    default:
      return wallpapers[0];
  }
}
