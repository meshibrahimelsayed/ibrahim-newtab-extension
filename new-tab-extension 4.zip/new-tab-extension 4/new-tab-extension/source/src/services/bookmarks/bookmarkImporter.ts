import { AppItem, Category } from "../../types";
import { createId } from "../../utils/id";
import { normalizeAppUrl, deriveAppNameFromUrl } from "../../utils/url";

export interface BookmarkImportResult {
  categories: Category[];
  apps: AppItem[];
  totalImported: number;
}

/**
 * Parses standard Netscape Bookmark HTML format (exported by Chrome, Firefox, Edge, Safari).
 * Extracts folder headers (H3) as Categories and links (A) as AppItems with site logos.
 * Automatically resolves clean names for any "Untitled" bookmarks.
 */
export function parseBookmarksHtml(htmlContent: string): BookmarkImportResult {
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlContent, "text/html");

  const categories: Category[] = [];
  const apps: AppItem[] = [];
  const seenUrls = new Set<string>();

  function processNode(node: Element, currentCategory: Category | null) {
    for (const child of Array.from(node.children)) {
      const tagName = child.tagName.toUpperCase();

      if (tagName === "DT") {
        const h3 = child.querySelector(":scope > H3, :scope > h3");
        if (h3) {
          const folderName = h3.textContent?.trim() || "Imported";
          const catName = folderName.replace(/^(Bookmarks bar|Bookmarks Menu|Other Bookmarks)$/i, "Bookmarks");
          
          let cat = categories.find((c) => c.name.toLowerCase() === catName.toLowerCase());
          if (!cat) {
            cat = {
              id: createId(),
              name: catName,
              order: categories.length,
              createdAt: Date.now()
            };
            categories.push(cat);
          }

          const dl = child.querySelector(":scope > DL, :scope > dl");
          if (dl) {
            processNode(dl, cat);
          }
          continue;
        }

        const a = child.querySelector(":scope > A, :scope > a");
        if (a) {
          const href = a.getAttribute("href") || a.getAttribute("HREF") || "";
          const rawName = a.textContent?.trim() || "";
          const iconAttr = a.getAttribute("icon") || a.getAttribute("ICON") || undefined;
          
          const normalized = normalizeAppUrl(href);
          if (normalized && !seenUrls.has(normalized)) {
            seenUrls.add(normalized);

            let targetCategory = currentCategory;
            if (!targetCategory) {
              targetCategory = categories.find((c) => c.name === "General") || {
                id: createId(),
                name: "General",
                order: categories.length,
                createdAt: Date.now()
              };
              if (!categories.includes(targetCategory)) {
                categories.push(targetCategory);
              }
            }

            // Clean name: never "Untitled"
            const name = deriveAppNameFromUrl(normalized, rawName);

            apps.push({
              id: createId(),
              name: name.slice(0, 50),
              url: normalized,
              categoryId: targetCategory.id,
              iconType: iconAttr && iconAttr.startsWith("data:") ? "custom" : "favicon",
              iconValue: iconAttr && iconAttr.startsWith("data:") ? iconAttr : undefined,
              favorite: false,
              order: apps.filter((x) => x.categoryId === targetCategory!.id).length,
              createdAt: Date.now()
            });
          }
        }
      } else if (tagName === "DL" || tagName === "P") {
        processNode(child, currentCategory);
      }
    }
  }

  const rootDl = doc.querySelector("dl, DL") || doc.body;
  if (rootDl) {
    processNode(rootDl, null);
  }

  return {
    categories,
    apps,
    totalImported: apps.length
  };
}

/**
 * Parses raw text containing URLs (one per line or comma-separated)
 */
export function parseRawUrls(text: string, categoryName = "Imported Links"): BookmarkImportResult {
  const lines = text.split(/[\r\n,]+/);
  const categories: Category[] = [
    {
      id: createId(),
      name: categoryName,
      order: 0,
      createdAt: Date.now()
    }
  ];
  const apps: AppItem[] = [];
  const seenUrls = new Set<string>();

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    const normalized = normalizeAppUrl(trimmed);
    if (normalized && !seenUrls.has(normalized)) {
      seenUrls.add(normalized);
      const name = deriveAppNameFromUrl(normalized);
      apps.push({
        id: createId(),
        name,
        url: normalized,
        categoryId: categories[0].id,
        iconType: "favicon",
        favorite: false,
        order: apps.length,
        createdAt: Date.now()
      });
    }
  }

  return {
    categories,
    apps,
    totalImported: apps.length
  };
}
