import React from "react";
import ReactDOM from "react-dom/client";
import { App } from "./components/App";
import { AppStateProvider } from "./store/AppStateContext";
import { ToastProvider } from "./components/common/Toast";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <AppStateProvider>
      <ToastProvider>
        <App />
      </ToastProvider>
    </AppStateProvider>
  </React.StrictMode>
);
