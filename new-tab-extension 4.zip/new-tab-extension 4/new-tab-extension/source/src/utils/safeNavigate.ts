/**
 * Defence-in-depth URL navigation guard.
 *
 * Every place in the app that navigates to a user-stored URL must go through
 * this function rather than assigning directly to `window.location.href`.
 * It re-validates protocol (http/https only) and hostname at click-time,
 * regardless of whether the URL was validated at save-time.
 */

type ToastFn = (msg: string, type?: "error" | "success") => void;

let _showToast: ToastFn | null = null;

/** Register the toast function so safeNavigate can show errors. */
export function registerToast(fn: ToastFn): void {
  _showToast = fn;
}

/**
 * Validates `url` and navigates to it if safe. Returns false if blocked.
 *
 * Allowed protocols: http:, https:
 * The hostname must contain at least one dot (prevents localhost-only or
 * exotic single-label hostnames). This mirrors the save-time validator but
 * runs again defensively at navigation-time.
 */
export function safeNavigate(url: string): boolean {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      _showToast?.(`Blocked navigation to unsafe URL scheme: ${parsed.protocol}`, "error");
      return false;
    }
    if (!parsed.hostname || !parsed.hostname.includes(".")) {
      _showToast?.("Blocked navigation — invalid URL hostname.", "error");
      return false;
    }
    window.location.href = url;
    return true;
  } catch {
    _showToast?.("Blocked navigation — the stored URL is malformed.", "error");
    return false;
  }
}
