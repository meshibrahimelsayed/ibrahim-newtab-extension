import { AppState, Category, AppItem, Settings } from "../types";
import { createId } from "./id";

export const SCHEMA_VERSION = 2;

export const DEFAULT_ACCENT = "#6f7d3c";
export const DEFAULT_HOVER_TINT = "#2f3a1c";

export function createDefaultSettings(): Settings {
  return {
    appearance: {
      theme: "light",
      accent: DEFAULT_ACCENT,
      glassIntensity: 62,
      hoverTint: DEFAULT_HOVER_TINT,
      glassBlur: 22,
      allowGoogleFavicons: true
    },
    background: {
      mode: "fixed",
      activeWallpaperId: null,
      playlistIds: [],
      brightness: 100,
      contrast: 100,
      blur: 0,
      saturation: 105,
      vignette: 18,
      overlay: 14,
      videoAutoplay: true
    },
    clock: {
      hour12: true,
      showSeconds: false,
      dateFormat: "long"
    },
    weather: {
      enabled: true,
      units: "metric",
      mode: "auto"
    },
    pomodoro: {
      focusMinutes: 25,
      shortBreakMinutes: 5,
      longBreakMinutes: 15,
      longBreakEvery: 4,
      autoStartNext: false,
      soundEnabled: true
    },
    layout: {
      widgets: {
        weather: true,
        calendar: true,
        pomodoro: true,
        projects: true,
        todo: true
      },
      gridDensity: "comfortable"
    },
    onboardingComplete: false
  };
}

/** Rich, organized seed data perfectly matching the reference dashboard */
export function createSeedData(): { categories: Category[]; apps: AppItem[] } {
  const now = Date.now();
  const categoryDefs = [
    {
      name: "Work",
      items: [
        ["Gmail", "https://mail.google.com"],
        ["Google Calendar", "https://calendar.google.com"],
        ["Slack", "https://slack.com"],
        ["Google Drive", "https://drive.google.com"],
        ["Zoom", "https://zoom.us"],
        ["LinkedIn", "https://linkedin.com"]
      ]
    },
    {
      name: "AI",
      items: [
        ["ChatGPT", "https://chatgpt.com"],
        ["Claude", "https://claude.ai"],
        ["Gemini", "https://gemini.google.com"],
        ["Perplexity", "https://perplexity.ai"],
        ["Grok", "https://x.com/i/grok"]
      ]
    },
    {
      name: "Food",
      items: [
        ["Uber Eats", "https://ubereats.com"],
        ["DoorDash", "https://doordash.com"],
        ["Chipotle", "https://chipotle.com"],
        ["yelp.com", "https://yelp.com"]
      ]
    },
    {
      name: "Learn",
      items: [
        ["Duolingo", "https://duolingo.com"],
        ["Khan Academy", "https://khanacademy.org"],
        ["Medium", "https://medium.com"],
        ["Coursera", "https://coursera.org"],
        ["Wikipedia", "https://wikipedia.org"]
      ]
    },
    {
      name: "Finance",
      items: [
        ["Chase", "https://chase.com"],
        ["Bank of America", "https://bankofamerica.com"],
        ["Credit Karma", "https://creditkarma.com"],
        ["Fidelity", "https://fidelity.com"],
        ["PayPal", "https://paypal.com"]
      ]
    },
    {
      name: "Shopping",
      items: [
        ["Amazon", "https://amazon.com"],
        ["Target", "https://target.com"],
        ["Best Buy", "https://bestbuy.com"],
        ["Etsy", "https://etsy.com"],
        ["eBay", "https://ebay.com"]
      ]
    },
    {
      name: "Social",
      items: [
        ["Instagram", "https://instagram.com"],
        ["X", "https://x.com"],
        ["LinkedIn", "https://linkedin.com"],
        ["Pinterest", "https://pinterest.com"]
      ]
    },
    {
      name: "Entertainment",
      items: [
        ["Netflix", "https://netflix.com"],
        ["YouTube", "https://youtube.com"],
        ["Spotify", "https://spotify.com"],
        ["Disney+", "https://disneyplus.com"],
        ["Hulu", "https://hulu.com"]
      ]
    },
    {
      name: "News",
      items: [
        ["The New York Times", "https://nytimes.com"],
        ["The Wall Street Journal", "https://wsj.com"],
        ["CNN", "https://cnn.com"],
        ["Reddit", "https://reddit.com"],
        ["The Verge", "https://theverge.com"]
      ]
    }
  ];

  const categories: Category[] = [];
  const apps: AppItem[] = [];

  categoryDefs.forEach((catDef, catIdx) => {
    const catId = createId();
    categories.push({
      id: catId,
      name: catDef.name,
      order: catIdx,
      createdAt: now
    });

    catDef.items.forEach(([name, url], itemIdx) => {
      apps.push({
        id: createId(),
        name,
        url,
        categoryId: catId,
        iconType: "favicon",
        favorite: false,
        order: itemIdx,
        createdAt: now
      });
    });
  });

  return { categories, apps };
}

export function createDefaultState(): AppState {
  const { categories, apps } = createSeedData();
  return {
    version: SCHEMA_VERSION,
    categories,
    apps,
    projects: [],
    wallpapers: [],
    settings: createDefaultSettings(),
    tasks: []
  };
}
