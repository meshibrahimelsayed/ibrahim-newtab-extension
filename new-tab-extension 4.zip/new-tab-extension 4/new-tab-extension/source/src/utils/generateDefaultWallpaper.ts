/**
 * We can't ship copyrighted stock photography or video inside the
 * extension, so the one built-in wallpaper is procedurally painted onto a
 * canvas at first run: a soft, abstract "aurora" gradient scene rendered at
 * the user's own screen resolution. Users add their own photos/videos for
 * anything beyond this default.
 */
export async function generateDefaultWallpaper(width: number, height: number): Promise<Blob> {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d")!;

  // Soft misty base
  const base = ctx.createLinearGradient(0, 0, 0, height);
  base.addColorStop(0, "#eef2ec");
  base.addColorStop(1, "#dde6dc");
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, width, height);

  const blobs: Array<[number, number, number, string, number]> = [
    [width * 0.22, height * 0.28, Math.max(width, height) * 0.42, "#a9c2a3", 0.55],
    [width * 0.78, height * 0.22, Math.max(width, height) * 0.38, "#c3d3d6", 0.45],
    [width * 0.62, height * 0.78, Math.max(width, height) * 0.46, "#f3e4c0", 0.28],
    [width * 0.12, height * 0.82, Math.max(width, height) * 0.3, "#d4dcc8", 0.3]
  ];

  ctx.globalCompositeOperation = "screen";
  for (const [x, y, r, color, alpha] of blobs) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, hexToRgba(color, alpha));
    g.addColorStop(1, hexToRgba(color, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalCompositeOperation = "source-over";

  // Subtle vignette to keep edges calm.
  const vignette = ctx.createRadialGradient(
    width / 2,
    height / 2,
    Math.min(width, height) * 0.3,
    width / 2,
    height / 2,
    Math.max(width, height) * 0.75
  );
  vignette.addColorStop(0, "rgba(0,0,0,0)");
  vignette.addColorStop(1, "rgba(0,0,0,0.45)");
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, width, height);

  // Fine film-grain texture for depth (kept very subtle for perf + taste).
  const grainCount = Math.floor((width * height) / 2600);
  ctx.fillStyle = "rgba(255,255,255,0.025)";
  for (let i = 0; i < grainCount; i++) {
    const gx = Math.random() * width;
    const gy = Math.random() * height;
    ctx.fillRect(gx, gy, 1, 1);
  }

  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error("Failed to render default wallpaper"));
    }, "image/png");
  });
}

function hexToRgba(hex: string, alpha: number): string {
  const n = parseInt(hex.replace("#", ""), 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return `rgba(${r},${g},${b},${alpha})`;
}
