/**
 * Validates and normalizes a user-supplied URL for an application shortcut.
 * Returns the normalized URL string, or null if the input isn't a usable
 * http(s) URL. We deliberately don't accept javascript:, data:, file:, or
 * other unsafe schemes.
 */
export function normalizeAppUrl(raw: string): string | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;

  const candidate = /^[a-zA-Z][a-zA-Z\d+\-.]*:\/\//.test(trimmed) ? trimmed : `https://${trimmed}`;

  try {
    const parsed = new URL(candidate);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
      return null;
    }
    if (!parsed.hostname || !parsed.hostname.includes(".")) {
      return null;
    }
    return parsed.toString();
  } catch {
    return null;
  }
}

export function faviconUrlFor(appUrl: string): string | null {
  try {
    const { hostname } = new URL(appUrl);
    return `https://www.google.com/s2/favicons?sz=64&domain=${encodeURIComponent(hostname)}`;
  } catch {
    return null;
  }
}

export function hostnameOf(appUrl: string): string {
  try {
    return new URL(appUrl).hostname.replace(/^www\./, "");
  } catch {
    return appUrl;
  }
}

/**
 * Derives a clean, readable name from a URL if the supplied title is missing or "Untitled".
 */
export function deriveAppNameFromUrl(appUrl: string, rawTitle?: string): string {
  const trimmed = (rawTitle || "").trim();
  if (trimmed && !/^untitled$/i.test(trimmed) && !/^untitled\s*\d*$/i.test(trimmed)) {
    return trimmed;
  }

  try {
    const parsed = new URL(appUrl);
    let host = parsed.hostname.replace(/^www\./, "");
    const parts = host.split(".");
    let mainName = parts[0];

    // Handle common subdomains like web.whatsapp.com, mail.google.com, docs.google.com
    if (parts.length >= 3 && ["web", "mail", "app", "mobile", "m", "docs", "drive"].includes(parts[0].toLowerCase())) {
      mainName = parts[1];
    }

    if (!mainName) return "Link";
    return mainName.charAt(0).toUpperCase() + mainName.slice(1);
  } catch {
    return trimmed || "Link";
  }
}

/**
 * Deterministic monogram color from a string (app name).
 * Produces an HSL hue that's visually distinct per name.
 */
export function monogramColorFor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
    hash |= 0; // force 32-bit int
  }
  const hue = ((hash % 360) + 360) % 360;
  return `hsl(${hue}, 55%, 55%)`;
}

/**
 * Extract up to 2 initials from a name for monogram display.
 */
export function monogramLetters(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return (name.trim().charAt(0) || "?").toUpperCase();
}
