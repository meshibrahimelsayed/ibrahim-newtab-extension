# New Tab


## Quick start — load the pre-built extension

1. Open `chrome://extensions` in Chrome.
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked**.
4. Select the `dist/` folder from this project.
5. Open a new tab — Aurora replaces Chrome's default New Tab page.

That's it — the `dist/` folder included here is a ready-to-load build, no build step required.

## Building from source

```bash
npm install
npm run build
```

This produces a fresh `dist/` folder (TypeScript build + Vite bundle + manifest/icons copied in). Load that folder the same way as above.

For local iteration in a normal browser tab (not as an extension — storage falls back to `localStorage` so you can still click around):

```bash
npm run dev
```

## Quick Save and the Saved hub

- Save the current tab with **Alt+Shift+S**, the toolbar button, or right-click → **Save to New Tab** (pages and links).
- Open the **Saved** view (**Alt+2**) to search, open, remove, or move a saved tab into a Home category.
- Saved tabs are searchable from the global search (**Ctrl+K** or **/**).
- Duplicates are skipped; the toolbar badge shows ✓ (saved), = (already saved) or ✕ (can't save this page).
- Change the shortcut at `chrome://extensions/shortcuts`. Other shortcuts: **Alt+1** Home, **Alt+3** Projects.
- Saved tabs live under their own storage key (`newtab_saved_v1`), written by the background service worker, so they never conflict with the dashboard state.


## What's implemented

- **Background engine** — static image and video wallpapers, poster-first loading, crossfade transitions, Page Visibility–based pause/resume, `prefers-reduced-motion` support, and an automatic fallback if media fails to load.
- **Wallpaper library** — add your own images/videos (stored in IndexedDB, never in `chrome.storage` — that's reserved for small structured settings), favorite/rename/delete, five wallpaper modes (fixed, random, daily, playlist, favorites-only), and live brightness/contrast/saturation/blur/vignette/overlay controls.
- **Board layout** — every category renders as a compact list-style card (name + rows, not icon tiles), flowing across the page in a masonry grid so the wallpaper stays visible between cards. Categories and rows are drag-to-reorder; a Favorites card appears automatically when you star anything.
- **Application launcher** — drag-and-drop reordering, favorites, custom or auto-fetched favicon icons with a generated-letter fallback, full add/edit/duplicate/delete, URL validation.
- **Global search** (⌘K / Ctrl+K or `/`) — searches apps, projects, and falls through to a web search.
- **Projects** — lightweight workspaces with notes and links.
- **First-run onboarding**, empty states, toasts, and error/fallback states throughout.

## What's intentionally not included

- No copyrighted stock photography or video ships with the extension — the one built-in wallpaper is a procedurally generated abstract gradient, painted on a canvas at first run. Add your own photos/videos in **Settings → Background**.
- No fake "coming soon" buttons — every visible control does what it says.

## Notes on permissions


## Shortcuts

Open the ⌘ button (bottom bar) or press **?** to see every shortcut, what it does, and to rebind the in-page ones (click **Change**, press the new keys). The Quick Save shortcut (Alt+Shift+S) is a Chrome shortcut; change it at `chrome://extensions/shortcuts`. The ▦ button changes bookmark card width and text size.

## Layout

Your bookmark cards fill the whole page. Use ▦ for card width and text size, and ⇅ (Alt+A) to reorder or sort cards precisely.
